# main.py – Orchestrate everything: load data, CV, final model, save
import os
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
from config_data import (load_and_preprocess, get_candidate_graphs,
                         RANDOM_SEED, N_FOLDS, device,
                         RESULT_BASE_DIR, OMICS_NAME)
from train_eval import train_fold, train_final_model, compute_saliency

def main():
    # 1. Load and preprocess data
    X_G, X_T, X_M, y_scaled, scaler_G, scaler_T, scaler_M, scaler_y = load_and_preprocess()
    adj_G, adj_T, adj_M = get_candidate_graphs(X_G, X_T, X_M)
    N_samples = X_G.shape[0]

    # 2. Cross-validation
    kf = KFold(n_splits=N_FOLDS, shuffle=True, random_state=RANDOM_SEED)
    all_results = []
    for fold, (train_idx, val_idx) in enumerate(kf.split(np.arange(N_samples)), 1):
        train_mask = torch.zeros(N_samples, dtype=torch.bool)
        val_mask = torch.zeros(N_samples, dtype=torch.bool)
        train_mask[train_idx] = True
        val_mask[val_idx] = True
        print(f"\n--- Fold {fold}/{N_FOLDS} (train: {len(train_idx)}, val: {len(val_idx)}) ---")
        res = train_fold(X_G, X_T, X_M, y_scaled, train_mask, val_mask,
                         adj_G, adj_T, adj_M, scaler_y, fold)
        all_results.append(res)
        print(f"Fold {fold} | PCC: {res['pcc']:.4f} | RMSE: {res['rmse']:.4f} | CCC: {res['ccc']:.4f}")

    # Save CV metrics
    df_metrics = pd.DataFrame([{k: res[k] for k in ['fold','pcc','rmse','ccc','training_time_sec','inference_time_sec']}
                               for res in all_results])
    print("\n========== FINAL CROSS-VALIDATION RESULTS ==========")
    print(f"PCC: {df_metrics['pcc'].mean():.4f} ± {df_metrics['pcc'].std():.4f}")
    print(f"RMSE: {df_metrics['rmse'].mean():.4f} ± {df_metrics['rmse'].std():.4f}")
    print(f"CCC: {df_metrics['ccc'].mean():.4f} ± {df_metrics['ccc'].std():.4f}")

    # 3. Train final model on all data for interpretability
    print("\nTraining final model on all data for interpretability...")
    final_model = train_final_model(X_G, X_T, X_M, y_scaled, adj_G, adj_T, adj_M, scaler_y)

    # 4. Save AFSC scaling weights (global interpretability)
    np.save(os.path.join(RESULT_BASE_DIR, "scaling_weights_G.npy"), final_model.omni_G.scaling.detach().cpu().numpy())
    np.save(os.path.join(RESULT_BASE_DIR, "scaling_weights_T.npy"), final_model.omni_T.scaling.detach().cpu().numpy())
    np.save(os.path.join(RESULT_BASE_DIR, "scaling_weights_M.npy"), final_model.omni_M.scaling.detach().cpu().numpy())

    # 5. Compute saliency (sensitivity of output to scaling weights)
    print("Computing saliency (∂pred/∂scaling) ...")
    grad_G, grad_T, grad_M = compute_saliency(final_model, X_G, X_T, X_M)
    np.save(os.path.join(RESULT_BASE_DIR, "saliency_G.npy"), grad_G)
    np.save(os.path.join(RESULT_BASE_DIR, "saliency_T.npy"), grad_T)
    np.save(os.path.join(RESULT_BASE_DIR, "saliency_M.npy"), grad_M)

    print("\nAll results and interpretability outputs saved.")
    print(f"Results directory: {RESULT_BASE_DIR}")

if __name__ == "__main__":
    import torch
    main()