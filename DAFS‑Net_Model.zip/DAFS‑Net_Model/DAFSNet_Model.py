# ============================================================
# models.py – All neural network components and the full DAFS‑Net model
# ============================================================
import torch
import torch.nn as nn
import torch.nn.functional as F
from config_data import (EMBED_DIM, OMNI_DROPOUT, HARD_CONCRETE_BETA,
                         HARD_CONCRETE_GAMMA, HARD_CONCRETE_ZETA,
                         GAT_HIDDEN, N_GAT_LAYERS, N_GAT_HEADS,
                         GAT_DROPOUT, device, sparse_log_const)

# ----------------------------------------------------------------------
# 1. AFSC: feature scaling + NTP‑compression (AFSC)
# ----------------------------------------------------------------------
class AFSC(nn.Module):
    def __init__(self, input_dim, embed_dim=EMBED_DIM, dropout=OMNI_DROPOUT):
        super().__init__()
        self.scaling = nn.Parameter(torch.ones(input_dim))
        self.fc1 = nn.Linear(input_dim, 256)
        self.norm1 = nn.LayerNorm(256)
        self.fc2 = nn.Linear(256, 128)
        self.norm2 = nn.LayerNorm(128)
        self.fc3 = nn.Linear(128, embed_dim)
        self.norm3 = nn.LayerNorm(embed_dim)
        self.dropout = nn.Dropout(dropout)
        self.leaky_relu = nn.LeakyReLU(0.01)

    def forward(self, x):
        x = x * self.scaling
        scale1 = 1.0 / (x.shape[1] ** 0.5)
        x = self.leaky_relu(self.norm1(self.fc1(x) * scale1))
        x = self.dropout(x)
        scale2 = 1.0 / (256 ** 0.5)
        x = self.leaky_relu(self.norm2(self.fc2(x) * scale2))
        x = self.dropout(x)
        scale3 = 1.0 / (128 ** 0.5)
        x = self.leaky_relu(self.norm3(self.fc3(x) * scale3))
        x = self.dropout(x)
        return x

# ----------------------------------------------------------------------
# 2. HardConcrete sparsification module (Eq 5‑8)
# ----------------------------------------------------------------------
class HardConcreteSparsification(nn.Module):
    def __init__(self, adj_initial, beta=HARD_CONCRETE_BETA,
                 gamma=HARD_CONCRETE_GAMMA, zeta=HARD_CONCRETE_ZETA):
        super().__init__()
        self.beta = beta
        self.gamma = gamma
        self.zeta = zeta
        self.register_buffer('mask_init', adj_initial)
        self.n_edges = torch.nonzero(self.mask_init).size(0)
        self.log_alpha = nn.Parameter(torch.randn(self.n_edges) * 0.1)

    def forward(self, training=True):
        edge_indices = torch.nonzero(self.mask_init, as_tuple=True)
        if edge_indices[0].numel() == 0:
            return self.mask_init, torch.tensor(0.0, device=self.mask_init.device)
        if training:
            u = torch.rand(self.n_edges, device=self.log_alpha.device)
            log_alpha = self.log_alpha
            s = torch.sigmoid((torch.log(u) - torch.log(1 - u) + log_alpha) / self.beta)
            s_bar = s * (self.zeta - self.gamma) + self.gamma
            mask_cont = torch.clamp(s_bar, min=0.0, max=1.0)
            sp_loss = torch.sigmoid(log_alpha - self.beta * sparse_log_const).sum()
        else:
            log_alpha = self.log_alpha
            s = torch.sigmoid(log_alpha / self.beta)
            s_bar = s * (self.zeta - self.gamma) + self.gamma
            mask_cont = torch.clamp(s_bar, min=0.0, max=1.0)
            sp_loss = torch.tensor(0.0, device=self.log_alpha.device)
        N = self.mask_init.shape[0]
        adj = torch.zeros((N, N), device=self.mask_init.device)
        adj[edge_indices] = mask_cont
        return adj, sp_loss

# ----------------------------------------------------------------------
# 3. Dynamic GAT layer & multi‑layer GAT
# ----------------------------------------------------------------------
class DynamicGATLayer(nn.Module):
    def __init__(self, in_features, out_features, heads=1, dropout=0.2):
        super().__init__()
        self.heads = heads
        self.linear = nn.ModuleList([nn.Linear(in_features, out_features, bias=False) for _ in range(heads)])
        self.attention = nn.ModuleList([nn.Linear(2 * out_features, 1, bias=False) for _ in range(heads)])
        self.dropout = nn.Dropout(dropout)
        self.leaky_relu = nn.LeakyReLU(0.2)

    def forward(self, x, adj):
        N = x.shape[0]
        outputs = []
        for h in range(self.heads):
            Wh = self.linear[h](x)
            h_i = Wh.unsqueeze(1).expand(-1, N, -1)
            h_j = Wh.unsqueeze(0).expand(N, -1, -1)
            h_cat = torch.cat([h_i, h_j], dim=-1)
            e = self.leaky_relu(self.attention[h](h_cat)).squeeze(-1)
            e = e * adj + (1 - adj) * (-1e9)
            alpha = torch.softmax(e, dim=1)
            alpha = self.dropout(alpha)
            out = torch.mm(alpha, Wh)
            outputs.append(out)
        return torch.stack(outputs, dim=0).mean(dim=0)

class DynamicGAT(nn.Module):
    def __init__(self, in_features, hidden, out_features, n_layers=2, heads=4, dropout=0.2):
        super().__init__()
        self.layers = nn.ModuleList()
        self.layers.append(DynamicGATLayer(in_features, hidden, heads=heads, dropout=dropout))
        for _ in range(n_layers - 1):
            self.layers.append(DynamicGATLayer(hidden, hidden, heads=heads, dropout=dropout))
        self.out_layer = nn.Linear(hidden, out_features)

    def forward(self, x, adj):
        for layer in self.layers:
            x = layer(x, adj)
            x = torch.relu(x)
        return self.out_layer(x)

# ----------------------------------------------------------------------
# 4. Multi‑view attention fusion (per‑sample omics weights)
# ----------------------------------------------------------------------
class InterViewAttentionFusion(nn.Module):
    def __init__(self, embed_dim, num_views=3, dropout=0.2):
        super().__init__()
        self.num_views = num_views
        self.projections = nn.ModuleList([nn.Linear(embed_dim, embed_dim) for _ in range(num_views)])
        self.beta = nn.ParameterList([nn.Parameter(torch.randn(embed_dim) * 0.1) for _ in range(num_views)])
        self.dropout = nn.Dropout(dropout)

    def forward(self, h_G, h_T, h_M):
        H = [h_G, h_T, h_M]
        H_prime = []
        scores = []
        for v, (h, proj, beta_vec) in enumerate(zip(H, self.projections, self.beta)):
            h_prime = proj(h)
            H_prime.append(h_prime)
            score = (h_prime * beta_vec).sum(dim=1)
            scores.append(score)
        scores_stack = torch.stack(scores, dim=1)
        alpha = F.softmax(scores_stack, dim=1)
        fused = torch.zeros_like(H_prime[0])
        for v in range(self.num_views):
            fused += alpha[:, v].unsqueeze(1) * H_prime[v]
        fused = self.dropout(fused)
        return fused, alpha

# ----------------------------------------------------------------------
# 5. Learned graph refinement (MLP on node embeddings)
# ----------------------------------------------------------------------
class LearnedAdjacencyRefinement(nn.Module):
    def __init__(self, embed_dim, hidden_dim=64):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(embed_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
            nn.Sigmoid()
        )

    def forward(self, emb, mask_init):
        edge_idx = torch.nonzero(mask_init, as_tuple=True)
        if edge_idx[0].numel() == 0:
            return mask_init
        emb_i = emb[edge_idx[0]]
        emb_j = emb[edge_idx[1]]
        concat = torch.cat([emb_i, emb_j], dim=1)
        weight = self.mlp(concat).squeeze(-1)
        adj = torch.zeros_like(mask_init)
        adj[edge_idx] = weight
        return adj

# ----------------------------------------------------------------------
# 6. Full DAFS‑Net model
# ----------------------------------------------------------------------
class DAFSNet(nn.Module):
    def __init__(self, dim_G, dim_T, dim_M, embed_dim=EMBED_DIM,
                 hidden_gat=GAT_HIDDEN, out_gat=EMBED_DIM,
                 n_gat_layers=N_GAT_LAYERS, gat_heads=N_GAT_HEADS,
                 dropout=OMNI_DROPOUT):
        super().__init__()
        self.omni_G = AFSC(dim_G, embed_dim, dropout)
        self.omni_T = AFSC(dim_T, embed_dim, dropout)
        self.omni_M = AFSC(dim_M, embed_dim, dropout)

        self.graph_refiner_G = LearnedAdjacencyRefinement(embed_dim)
        self.graph_refiner_T = LearnedAdjacencyRefinement(embed_dim)
        self.graph_refiner_M = LearnedAdjacencyRefinement(embed_dim)

        self.sparsify_G = None
        self.sparsify_T = None
        self.sparsify_M = None

        self.gat_G = DynamicGAT(embed_dim, hidden_gat, out_gat,
                                n_layers=n_gat_layers, heads=gat_heads, dropout=GAT_DROPOUT)
        self.gat_T = DynamicGAT(embed_dim, hidden_gat, out_gat,
                                n_layers=n_gat_layers, heads=gat_heads, dropout=GAT_DROPOUT)
        self.gat_M = DynamicGAT(embed_dim, hidden_gat, out_gat,
                                n_layers=n_gat_layers, heads=gat_heads, dropout=GAT_DROPOUT)

        self.fusion = InterViewAttentionFusion(out_gat, num_views=3, dropout=dropout)
        self.regressor = nn.Linear(out_gat, 1)

    def set_sparsify(self, adj_G_init, adj_T_init, adj_M_init):
        self.sparsify_G = HardConcreteSparsification(adj_G_init)
        self.sparsify_T = HardConcreteSparsification(adj_T_init)
        self.sparsify_M = HardConcreteSparsification(adj_M_init)
        self.sparsify_G.to(adj_G_init.device)
        self.sparsify_T.to(adj_T_init.device)
        self.sparsify_M.to(adj_M_init.device)
        self.register_buffer('mask_init_G', adj_G_init)
        self.register_buffer('mask_init_T', adj_T_init)
        self.register_buffer('mask_init_M', adj_M_init)

    def forward(self, x_G, x_T, x_M, training=True):
        emb_G = self.omni_G(x_G)
        emb_T = self.omni_T(x_T)
        emb_M = self.omni_M(x_M)

        refined_G = self.graph_refiner_G(emb_G, self.mask_init_G)
        refined_T = self.graph_refiner_T(emb_T, self.mask_init_T)
        refined_M = self.graph_refiner_M(emb_M, self.mask_init_M)

        adj_G_hc, sp_loss_G = self.sparsify_G(training=training)
        adj_T_hc, sp_loss_T = self.sparsify_T(training=training)
        adj_M_hc, sp_loss_M = self.sparsify_M(training=training)

        adj_G = adj_G_hc * refined_G
        adj_T = adj_T_hc * refined_T
        adj_M = adj_M_hc * refined_M

        N = adj_G.shape[0]
        adj_G = adj_G + torch.eye(N, device=adj_G.device)
        adj_T = adj_T + torch.eye(N, device=adj_T.device)
        adj_M = adj_M + torch.eye(N, device=adj_M.device)

        h_G = self.gat_G(emb_G, adj_G)
        h_T = self.gat_T(emb_T, adj_T)
        h_M = self.gat_M(emb_M, adj_M)

        h_fused, attn = self.fusion(h_G, h_T, h_M)
        pred = self.regressor(h_fused)

        sp_loss_individual = sp_loss_G + sp_loss_T + sp_loss_M
        co_sparsity = (adj_G_hc.mean() * adj_T_hc.mean() * adj_M_hc.mean())

        return pred, sp_loss_individual, co_sparsity, attn