# ============================================================
# train_eval.py – Training loop, cross‑validation, metrics, interpretability
# ============================================================
import time
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from scipy.stats import pearsonr
from config_data import (LR, WEIGHT_DECAY, N_EPOCHS,
                         LAMBDA_SPARSE_EDGE, LAMBDA_JOINT_SPARSE,
                         device, RESULT_BASE_DIR, OMICS_NAME)
from DAFSNet_Model import DAFSNet   # <-- changed

def concordance_correlation_coefficient(y_true, y_pred):
    mean_true = np.mean(y_true)
    mean_pred = np.mean(y_pred)
    var_true = np.var(y_true)
    var_pred = np.var(y_pred)
    cov = np.cov(y_true, y_pred)[0, 1]
    numerator = 2 * cov
    denominator = var_true + var_pred + (mean_true - mean_pred) ** 2
    return numerator / denominator if denominator != 0 else 0

def train_fold(X_G, X_T, X_M, y, train_mask, val_mask,
               adj_G, adj_T, adj_M, scaler_y, fold_num):
    X_G_t = torch.tensor(X_G, dtype=torch.float32).to(device)
    X_T_t = torch.tensor(X_T, dtype=torch.float32).to(device)
    X_M_t = torch.tensor(X_M, dtype=torch.float32).to(device)
    y_t = torch.tensor(y, dtype=torch.float32).view(-1, 1).to(device)

    model = DAFSNet(   # <-- changed
        dim_G=X_G.shape[1], dim_T=X_T.shape[1], dim_M=X_M.shape[1]
    ).to(device)
    model.set_sparsify(adj_G, adj_T, adj_M)

    optimizer = optim.Adam(model.parameters(), lr=LR, weight_decay=WEIGHT_DECAY)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=10)
    criterion = nn.MSELoss()

    best_val_loss = float('inf')
    best_state = None
    train_start = time.time()

    for epoch in range(N_EPOCHS):
        model.train()
        pred, sp_individual, co_sparsity, _ = model(X_G_t, X_T_t, X_M_t, training=True)
        loss_train = criterion(pred[train_mask], y_t[train_mask])
        loss = loss_train + LAMBDA_SPARSE_EDGE * sp_individual + LAMBDA_JOINT_SPARSE * co_sparsity
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        model.eval()
        with torch.no_grad():
            pred_val, _, _, _ = model(X_G_t, X_T_t, X_M_t, training=False)
            loss_val = criterion(pred_val[val_mask], y_t[val_mask]).item()
        scheduler.step(loss_val)

        if loss_val < best_val_loss:
            best_val_loss = loss_val
            best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}

    train_time = time.time() - train_start
    model.load_state_dict(best_state)
    model.eval()
    infer_start = time.time()
    with torch.no_grad():
        pred_val, _, _, _ = model(X_G_t, X_T_t, X_M_t, training=False)
    infer_time = time.time() - infer_start

    y_true = scaler_y.inverse_transform(y_t[val_mask].cpu().numpy().reshape(-1, 1)).flatten()
    y_pred = scaler_y.inverse_transform(pred_val[val_mask].cpu().numpy().reshape(-1, 1)).flatten()
    pcc = pearsonr(y_true, y_pred)[0]
    rmse = np.sqrt(np.mean((y_true - y_pred) ** 2))
    ccc = concordance_correlation_coefficient(y_true, y_pred)

    return {
        'fold': fold_num,
        'pcc': pcc,
        'rmse': rmse,
        'ccc': ccc,
        'training_time_sec': train_time,
        'inference_time_sec': infer_time,
        'y_true': y_true,
        'y_pred': y_pred
    }

def train_final_model(X_G, X_T, X_M, y, adj_G, adj_T, adj_M, scaler_y):
    X_G_t = torch.tensor(X_G, dtype=torch.float32).to(device)
    X_T_t = torch.tensor(X_T, dtype=torch.float32).to(device)
    X_M_t = torch.tensor(X_M, dtype=torch.float32).to(device)
    y_t = torch.tensor(y, dtype=torch.float32).view(-1, 1).to(device)

    model = DAFSNet(   # <-- changed
        dim_G=X_G.shape[1], dim_T=X_T.shape[1], dim_M=X_M.shape[1]
    ).to(device)
    model.set_sparsify(adj_G, adj_T, adj_M)

    optimizer = optim.Adam(model.parameters(), lr=LR, weight_decay=WEIGHT_DECAY)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=10)
    criterion = nn.MSELoss()

    best_loss = float('inf')
    best_state = None
    for epoch in range(N_EPOCHS):
        model.train()
        pred, sp_individual, co_sparsity, _ = model(X_G_t, X_T_t, X_M_t, training=True)
        loss = criterion(pred, y_t) + LAMBDA_SPARSE_EDGE * sp_individual + LAMBDA_JOINT_SPARSE * co_sparsity
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        model.eval()
        with torch.no_grad():
            pred_val, _, _, _ = model(X_G_t, X_T_t, X_M_t, training=False)
            loss_val = criterion(pred_val, y_t).item()
            pred_orig = scaler_y.inverse_transform(pred_val.cpu().numpy()).flatten()
            y_orig = scaler_y.inverse_transform(y_t.cpu().numpy()).flatten()
            corr = pearsonr(pred_orig, y_orig)[0]
        scheduler.step(loss_val)
        if loss_val < best_loss:
            best_loss = loss_val
            best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}
        if (epoch+1) % 20 == 0:
            print(f"Epoch {epoch+1:3d} | Loss: {loss_val:.4f} | PCC: {corr:.4f}")

    model.load_state_dict(best_state)
    return model

def compute_saliency(model, X_G, X_T, X_M):
    """Compute ∂(sum(pred)) / ∂(scaling weights) as a saliency measure."""
    X_G_t = torch.tensor(X_G, dtype=torch.float32, requires_grad=True).to(device)
    X_T_t = torch.tensor(X_T, dtype=torch.float32, requires_grad=True).to(device)
    X_M_t = torch.tensor(X_M, dtype=torch.float32, requires_grad=True).to(device)
    model.eval()
    pred, _, _, _ = model(X_G_t, X_T_t, X_M_t, training=False)
    loss = pred.sum()
    model.zero_grad()
    loss.backward(retain_graph=True)
    grad_G = model.omni_G.scaling.grad.clone().detach() if model.omni_G.scaling.grad is not None else torch.zeros_like(model.omni_G.scaling)
    grad_T = model.omni_T.scaling.grad.clone().detach() if model.omni_T.scaling.grad is not None else torch.zeros_like(model.omni_T.scaling)
    grad_M = model.omni_M.scaling.grad.clone().detach() if model.omni_M.scaling.grad is not None else torch.zeros_like(model.omni_M.scaling)
    return grad_G.cpu().numpy(), grad_T.cpu().numpy(), grad_M.cpu().numpy()