# ============================================================
# config_data.py – Paths, hyperparameters, data loading, preprocessing
# ============================================================
import os
import numpy as np
import pandas as pd
import torch
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import KFold
from sklearn.metrics.pairwise import cosine_similarity
import warnings
warnings.filterwarnings('ignore')

# ========== USER: EDIT THESE PATHS ==========
DATA_DIR = r"your_data_save_path"
T_FILE = os.path.join(DATA_DIR, "T_matrix.npy")
M_FILE = os.path.join(DATA_DIR, "M_gbM_matrix.npy")
M_FILE = os.path.join(DATA_DIR, "G_matrix.npy")

PHENO_FILE = os.path.join(DATA_DIR, "phenotypes.xlsx")
TARGET_COL = "DoR"
RANDOM_SEED = 42

RESULT_BASE_DIR = r"D:your_results_save_path"
os.makedirs(RESULT_BASE_DIR, exist_ok=True)
OMICS_NAME = "MultiOmics"

# ========== Hyperparameters (as in your script) ==========
EMBED_DIM = 64
OMNI_DROPOUT = 0.2
K_NEIGHBORS = 25                  # for initial candidate graph (cosine kNN)

# HardConcrete
HARD_CONCRETE_BETA = 2/3
HARD_CONCRETE_GAMMA = -0.1
HARD_CONCRETE_ZETA = 1.1
LAMBDA_SPARSE_EDGE = 1e-3

# Joint sparsity
LAMBDA_JOINT_SPARSE = 1e-3

# Dynamic GAT
N_GAT_LAYERS = 2
N_GAT_HEADS = 4
GAT_HIDDEN = 64
GAT_DROPOUT = 0.2

# Training
N_EPOCHS = 100
LR = 1e-3
WEIGHT_DECAY = 1e-5
N_FOLDS = 10

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {device}")
torch.manual_seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

def load_and_preprocess():
    print("Loading data...")
    G_full = np.load(G_FILE).astype(np.float32)
    T_full = np.load(T_FILE).astype(np.float32)
    M_full = np.load(M_FILE).astype(np.float32)
    print(f"Raw shapes: G {G_full.shape}, T {T_full.shape}, M {M_full.shape}")

    pheno_df = pd.read_excel(PHENO_FILE, engine='openpyxl')
    y_raw = pheno_df[TARGET_COL].values.astype(np.float32)
    assert G_full.shape[0] == T_full.shape[0] == M_full.shape[0] == y_raw.shape[0]
    N_samples = G_full.shape[0]
    print(f"Samples: {N_samples}")

    # Use all features (no selection)
    X_G_raw = G_full
    X_T_raw = T_full
    X_M_raw = M_full

    # Standardise each omics separately
    scaler_G = StandardScaler()
    X_G_scaled = scaler_G.fit_transform(X_G_raw)
    scaler_T = StandardScaler()
    X_T_scaled = scaler_T.fit_transform(X_T_raw)
    scaler_M = StandardScaler()
    X_M_scaled = scaler_M.fit_transform(X_M_raw)

    scaler_y = StandardScaler()
    y_scaled = scaler_y.fit_transform(y_raw.reshape(-1, 1)).flatten()

    return (X_G_scaled, X_T_scaled, X_M_scaled, y_scaled,
            scaler_G, scaler_T, scaler_M, scaler_y)

def build_cosine_knn_graph(features, k=K_NEIGHBORS):
    """Build binary adjacency matrix using cosine similarity kNN."""
    sim = cosine_similarity(features)
    N = features.shape[0]
    adj = np.zeros((N, N))
    for i in range(N):
        sim_i = sim[i].copy()
        sim_i[i] = -np.inf
        top_k_idx = np.argsort(sim_i)[-k:]
        adj[i, top_k_idx] = 1
    adj = np.maximum(adj, adj.T)
    return adj

def get_candidate_graphs(X_G, X_T, X_M):
    """Return torch tensors of initial binary graphs for G, T, M."""
    print("Building initial candidate graphs (used as mask for HardConcrete)...")
    adj_G = build_cosine_knn_graph(X_G, k=K_NEIGHBORS)
    adj_T = build_cosine_knn_graph(X_T, k=K_NEIGHBORS)
    adj_M = build_cosine_knn_graph(X_M, k=K_NEIGHBORS)
    print(f"Edges: G {adj_G.sum()//2}, T {adj_T.sum()//2}, M {adj_M.sum()//2}")
    adj_G_t = torch.tensor(adj_G, dtype=torch.float32).to(device)
    adj_T_t = torch.tensor(adj_T, dtype=torch.float32).to(device)
    adj_M_t = torch.tensor(adj_M, dtype=torch.float32).to(device)
    return adj_G_t, adj_T_t, adj_M_t

# Pre‑compute constant used in HardConcrete (shared globally)
sparse_const = torch.tensor(HARD_CONCRETE_GAMMA / HARD_CONCRETE_ZETA, dtype=torch.float32).to(device)
sparse_log_const = torch.log(-sparse_const)