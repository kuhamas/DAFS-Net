import pandas as pd
import numpy as np
import re
import os
from bisect import bisect_right

# ============================================
# CONFIGURATION
# ============================================
DATA_DIR = r"D:your_path"
GFF_FILE = os.path.join(DATA_DIR, "TAIR10_GFF3_genes.gff")
SNP_META_FILE = os.path.join(DATA_DIR, "snp_metadata.csv")
OUTPUT_MAPPING = os.path.join(DATA_DIR, "snp_to_gene.csv")

# ============================================
# Helper: Normalise chromosome name to "ChrX"
# ============================================
def normalise_chromosome(chrom):
    """
    Convert various chromosome name formats to standard "Chr1".."Chr5".
    Examples: "1", "chr1", "Chr1", "CHR1", "1" -> "Chr1"
    """
    chrom = str(chrom).strip()
    # Remove any 'chr' or 'Chr' prefix (case‑insensitive)
    chrom = re.sub(r'^(chr|Chr|CHR)', '', chrom)
    # If it's a number (1..5), prepend "Chr"
    if chrom.isdigit() and 1 <= int(chrom) <= 5:
        return f"Chr{chrom}"
    # If it's already "Chr1" etc., return as is
    if chrom in ["Chr1", "Chr2", "Chr3", "Chr4", "Chr5"]:
        return chrom
    # If it's something else (e.g., "Mt"), keep but warn
    print(f"Warning: unexpected chromosome name '{chrom}', keeping as is")
    return chrom

# ============================================
# 1. Load SNP metadata
# ============================================
print("Loading SNP metadata...")
snp_df = pd.read_csv(SNP_META_FILE)
if 'chromosome' not in snp_df.columns or 'position' not in snp_df.columns:
    raise ValueError("snp_metadata.csv must have 'chromosome' and 'position' columns")

# Normalise chromosome names and add a 0‑based index
snp_df['chrom_norm'] = snp_df['chromosome'].apply(normalise_chromosome)
snp_df['snp_idx'] = np.arange(len(snp_df))
print(f"Loaded {len(snp_df)} SNPs")
print(f"Unique chromosomes in SNP file: {snp_df['chrom_norm'].unique()}")

# ============================================
# 2. Parse GFF and extract genes
# ============================================
print("Parsing GFF file...")
genes = []  # list of (chromosome, start, end, gene_id)
with open(GFF_FILE, 'r') as f:
    for line in f:
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        parts = line.split('\t')
        if len(parts) < 9:
            continue
        chrom = parts[0]
        feat_type = parts[2]
        start = int(parts[3])
        end = int(parts[4])
        attrs = parts[8]
        if feat_type == 'gene':
            # Extract gene ID (e.g., ID=AT1G01010;...)
            match = re.search(r'ID=([^;]+)', attrs)
            if match:
                gene_id = match.group(1)
                genes.append((chrom, start, end, gene_id))

gene_df = pd.DataFrame(genes, columns=['chrom', 'start', 'end', 'gene_id'])
print(f"Extracted {len(gene_df)} genes")
print(f"Chromosomes in GFF: {gene_df['chrom'].unique()}")

# Group genes by chromosome and sort by start position
genes_by_chr = {}
for _, row in gene_df.iterrows():
    chrom = row['chrom']
    if chrom not in genes_by_chr:
        genes_by_chr[chrom] = []
    genes_by_chr[chrom].append((row['start'], row['end'], row['gene_id']))
for chrom in genes_by_chr:
    genes_by_chr[chrom].sort(key=lambda x: x[0])  # sort by start

# ============================================
# 3. Map SNPs to genes (binary search per chromosome)
# ============================================
print("Mapping SNPs to genes...")
def find_overlapping_genes(chrom, pos):
    """
    Return list of gene_ids whose interval contains pos.
    """
    if chrom not in genes_by_chr:
        return []
    gene_list = genes_by_chr[chrom]
    # Binary search for the rightmost gene with start <= pos
    left = bisect_right([g[0] for g in gene_list], pos) - 1
    if left < 0:
        return []
    overlapping = []
    # Scan forward until start > pos
    for i in range(left, len(gene_list)):
        if gene_list[i][0] > pos:
            break
        if gene_list[i][0] <= pos <= gene_list[i][1]:
            overlapping.append(gene_list[i][2])
    return overlapping

mapping_rows = []
for idx, row in snp_df.iterrows():
    chrom = row['chrom_norm']
    pos = row['position']
    gene_ids = find_overlapping_genes(chrom, pos)
    for gid in gene_ids:
        mapping_rows.append({
            'snp_idx': row['snp_idx'],
            'gene_id': gid
        })

mapping_df = pd.DataFrame(mapping_rows)
print(f"Found {len(mapping_df)} SNP‑gene associations (some SNPs may have multiple genes)")
if len(mapping_df) == 0:
    print("\n⚠️ No SNP‑gene associations found. Possible reasons:")
    print("   1. Chromosome name mismatch – see printed unique chromosomes above.")
    print("   2. Position coordinates are out of range (e.g., 0‑based vs 1‑based).")
    print("   3. The GFF file may not contain standard gene features (check 'feat_type' column).")
    print("   4. SNP positions may be outside annotated genes (intergenic).")
else:
    print(f"Example: first 5 associations:\n{mapping_df.head()}")

# ============================================
# 4. Save mapping
# ============================================
mapping_df.to_csv(OUTPUT_MAPPING, index=False)
print(f"Saved mapping to {OUTPUT_MAPPING}")