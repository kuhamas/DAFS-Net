import pandas as pd
import numpy as np
import os

# ============================================
# CONFIGURATION
# ============================================
T_FILE = r"your_path\GSE80744_ath1001_tx_norm_2016-04-21-UQ_gNorm_normCounts_k4.tsv"
MASTER_ACC_FILE = r"your_path\accessions_383.txt"
OUTPUT_DIR = r"your_path\T_processed_data"

# ============================================
# 1. Load master accession list
# ============================================
with open(MASTER_ACC_FILE, 'r') as f:
    master_accessions = [line.strip() for line in f]
print(f"Master list contains {len(master_accessions)} accessions")

# ============================================
# 2. Load transcriptomic TSV
# ============================================
print("Loading transcriptomic TSV...")
df = pd.read_csv(T_FILE, sep='\t', index_col=0)   # first column 'gene_id' becomes index
print(f"Raw data shape: {df.shape} (genes × samples)")

# ============================================
# 3. Clean column names: remove 'X' prefix
# ============================================
df.columns = df.columns.str.lstrip('X')   # 'X108' -> '108'
print("First few column names after cleaning:", df.columns[:5].tolist())

# ============================================
# 4. Subset and reorder columns to match master list
# ============================================
# Keep only columns that are in master_accessions
common_acc = [acc for acc in master_accessions if acc in df.columns]
print(f"Found {len(common_acc)} accessions out of {len(master_accessions)}")
if len(common_acc) < len(master_accessions):
    missing = set(master_accessions) - set(common_acc)
    print(f"Missing accessions: {list(missing)[:5]}")
df = df[common_acc]   # subset

# Reorder columns according to master list order
df = df[master_accessions]   # this will reorder and also raise error if any missing; we already ensured common_acc
print(f"Aligned data shape: {df.shape} (genes × accessions)")

# ============================================
# 5. Log transform (ln(1 + x))
# ============================================
# The paper used ln(TPM+1). Here we apply ln(1 + count) as a reasonable proxy.
X_counts = df.values.astype(np.float32)
X_log = np.log1p(X_counts)   # natural log
print(f"Transformed data range: [{X_log.min():.2f}, {X_log.max():.2f}]")

# ============================================
# 6. Transpose to accessions × genes (standard ML format)
# ============================================
T_matrix = X_log.T   # shape: (n_accessions, n_genes)
print(f"T_matrix shape: {T_matrix.shape}")

# ============================================
# 7. Save outputs
# ============================================
np.save(os.path.join(OUTPUT_DIR, "T_matrix.npy"), T_matrix)
print(f"Saved T_matrix.npy")

# Save gene names (original index)
gene_names = df.index.values
np.save(os.path.join(OUTPUT_DIR, "T_gene_names.npy"), gene_names)
print(f"Saved T_gene_names.npy with {len(gene_names)} genes")

# Save a small sample CSV for inspection
sample_df = pd.DataFrame(T_matrix[:10, :10],
                         index=master_accessions[:10],
                         columns=gene_names[:10])
sample_df.to_csv(os.path.join(OUTPUT_DIR, "T_matrix_sample.csv"))
print("Saved T_matrix_sample.csv (10x10)")

print("\n✅ Transcriptomic data preprocessing completed.")