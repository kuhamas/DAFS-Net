#!/usr/bin/env python3
"""
Preprocess genomic data (G) for the 383 accessions.
Reads accession IDs from your new Excel file (first column 'ID').
"""
#### you can download the
import h5py
import numpy as np
import pandas as pd
import os

# ============================================
# CONFIGURATION – UPDATE PATHS IF NEEDED
# ============================================
HDF5_PATH = r"your_path\imputed_snps_binary.hdf5"
EXCEL_PATH = r"your_path\Accession_ID.xlsx"
OUTPUT_DIR = r"your_path\G_processed_data"
os.makedirs(OUTPUT_DIR, exist_ok=True)

CHUNK_SIZE = 20000
MAF_THRESHOLD = 0.05

# ============================================
# 1. READ ACCESSION IDs FROM YOUR NEW EXCEL
# ============================================
print("Reading accession IDs from Excel (column 'ID')...")
df_acc = pd.read_excel(EXCEL_PATH, engine='openpyxl')
# Try column 'ID' first; if not found, take first column
if 'ID' in df_acc.columns:
    accession_list = df_acc['ID'].astype(str).tolist()
else:
    # fallback to first column
    accession_list = df_acc.iloc[:, 0].astype(str).tolist()
print(f"Loaded {len(accession_list)} accessions")

# Save as text file for reference
with open(os.path.join(OUTPUT_DIR, "accessions_383.txt"), "w") as f:
    for acc in accession_list:
        f.write(acc + "\n")

# ============================================
# 2. OPEN HDF5 AND MATCH ACCESSIONS
# ============================================
print("Opening HDF5 file...")
with h5py.File(HDF5_PATH, 'r') as f:
    all_accessions = f['accessions'][:].astype(str)
    print(f"Total accessions in HDF5: {len(all_accessions)}")

    # Map accession ID to index
    acc_to_idx = {acc: i for i, acc in enumerate(all_accessions)}
    keep_idx = []
    missing = []
    for acc in accession_list:
        if acc in acc_to_idx:
            keep_idx.append(acc_to_idx[acc])
        else:
            missing.append(acc)
    if missing:
        print(f"WARNING: {len(missing)} accessions not found. First few: {missing[:5]}")
    keep_idx = np.array(keep_idx)
    n_acc = len(keep_idx)
    print(f"Keeping {n_acc} accessions")

    acc_subset = all_accessions[keep_idx]
    np.save(os.path.join(OUTPUT_DIR, "accessions.npy"), acc_subset)

    # Get chromosome regions and positions
    chr_regions = f['positions'].attrs['chr_regions']
    positions = f['positions'][:]
    n_snps_total = len(positions)
    print(f"Total SNPs: {n_snps_total}")

    # Precompute chromosome labels
    chr_labels = np.zeros(n_snps_total, dtype=np.int8)
    for chr_idx, (start, end) in enumerate(chr_regions):
        chr_labels[start:end] = chr_idx + 1

    filtered_chunks = []
    snp_metadata = []
    total_kept = 0

    # ============================================
    # 3. PROCESS SNPs IN CHUNKS
    # ============================================
    for start in range(0, n_snps_total, CHUNK_SIZE):
        end = min(start + CHUNK_SIZE, n_snps_total)
        print(f"Processing SNPs {start} to {end}...")

        snp_chunk = f['snps'][start:end, :]
        snp_chunk = snp_chunk[:, keep_idx]

        recoded = np.zeros((snp_chunk.shape[0], n_acc), dtype=np.int8)
        maf_vals = np.zeros(snp_chunk.shape[0], dtype=np.float32)

        for i in range(snp_chunk.shape[0]):
            row = snp_chunk[i, :]
            cnt0 = np.count_nonzero(row == 0)
            cnt2 = np.count_nonzero(row == 2)
            if cnt0 >= cnt2:
                recoded[i, row == 0] = 1
                recoded[i, row == 2] = -1
            else:
                recoded[i, row == 2] = 1
                recoded[i, row == 0] = -1
            n_minor = 2 * np.count_nonzero(recoded[i, :] == -1) + np.count_nonzero(recoded[i, :] == 0)
            maf_vals[i] = n_minor / (2 * n_acc)

        keep = maf_vals >= MAF_THRESHOLD
        kept_count = np.sum(keep)
        if kept_count > 0:
            filtered_chunks.append(recoded[keep, :])
            for idx_in_chunk in np.where(keep)[0]:
                global_idx = start + idx_in_chunk
                snp_metadata.append((chr_labels[global_idx], positions[global_idx]))
            total_kept += kept_count
        print(f"  Kept {kept_count} SNPs (total: {total_kept})")

    # ============================================
    # 4. CONCATENATE AND SAVE
    # ============================================
    print("Concatenating chunks...")
    G_filtered = np.vstack(filtered_chunks)
    print(f"Final shape (SNPs × accessions): {G_filtered.shape}")
    G_T = G_filtered.T
    np.save(os.path.join(OUTPUT_DIR, "G_matrix.npy"), G_T)
    print(f"Saved G_matrix.npy of shape {G_T.shape}")

    meta_df = pd.DataFrame(snp_metadata, columns=["chromosome", "position"])
    meta_df.to_csv(os.path.join(OUTPUT_DIR, "snp_metadata.csv"), index=False)
    print(f"Saved snp_metadata.csv with {len(meta_df)} rows")

    # Sample CSV (first 10 rows, 10 columns)
    sample_df = pd.DataFrame(G_T[:10, :10],
                             index=acc_subset[:10],
                             columns=[f"SNP_{i}" for i in range(10)])
    sample_df.to_csv(os.path.join(OUTPUT_DIR, "G_matrix_sample.csv"))
    print("Saved G_matrix_sample.csv (10x10)")

print("\n✅ Done. Files in:", OUTPUT_DIR)