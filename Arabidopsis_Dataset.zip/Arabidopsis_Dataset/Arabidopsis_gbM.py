import pandas as pd
import numpy as np
from sklearn.impute import KNNImputer
import os

# ============================================
# CONFIGURATION
# ============================================
RAW_DIR = r"your_path\methylation_raw"
MAPPING_FILE = os.path.join(RAW_DIR, "Accession_ID_for_methylation_1107.txt")
MASTER_ACC_FILE = r"your_path\accessions_383.txt"
OUTPUT_DIR = r"your_path\gbM_processed_data"
os.makedirs(OUTPUT_DIR, exist_ok=True)

contexts = {
    'mCG': 'Araport11_GB_mCG_strict.tsv',
    'mCHG': 'Araport11_GB_mCHG_strict.tsv',
    'mCHH': 'Araport11_GB_mCHH_strict.tsv'
}

# ============================================
# 1. Load mapping of column index to accession ID
# ============================================
print("Loading mapping file...")
with open(MAPPING_FILE, 'r') as f:
    raw_accessions = [line.strip() for line in f]
print(f"Loaded {len(raw_accessions)} accession IDs from mapping file.")

# ============================================
# 2. Load master accession list
# ============================================
with open(MASTER_ACC_FILE, 'r') as f:
    master_accessions = [line.strip() for line in f]
print(f"Master list contains {len(master_accessions)} accessions.")

# ============================================
# 3. Process each context (handling duplicates)
# ============================================
all_dfs = []

for ctx_name, file_name in contexts.items():
    print(f"\nProcessing {ctx_name}...")
    file_path = os.path.join(RAW_DIR, file_name)

    # Read TSV (no header, first column is gene ID)
    df = pd.read_csv(file_path, sep='\t', header=None, index_col=0)
    print(f"Raw shape: {df.shape} (genes × samples)")

    # Assign column names from mapping
    if df.shape[1] != len(raw_accessions):
        raise ValueError(f"Column count mismatch: TSV has {df.shape[1]} but mapping has {len(raw_accessions)}")
    df.columns = raw_accessions

    # Collapse duplicate columns by taking median (as in official script)
    dup_cols = df.columns[df.columns.duplicated()].unique()
    if len(dup_cols) > 0:
        print(f"  Found duplicate accessions. Collapsing with median...")
        df = df.groupby(level=0, axis=1).median()
        print(f"  After collapsing: {df.shape}")

    # Subset to master accessions
    common = [acc for acc in master_accessions if acc in df.columns]
    print(f"Found {len(common)} out of {len(master_accessions)} accessions.")
    df = df[common]

    # Transpose to accessions × genes
    df = df.T
    print(f"Transposed shape: {df.shape} (accessions × genes)")

    # Add prefix to column names
    df = df.add_prefix(f'GB_{ctx_name}_')
    all_dfs.append(df)

# ============================================
# 4. Combine all contexts
# ============================================
print("\nCombining all contexts...")
df_combined = pd.concat(all_dfs, axis=1)
print(f"Combined shape: {df_combined.shape} (accessions × features)")

# Ensure rows are in the exact order of master list
df_combined = df_combined.reindex(master_accessions)
print(f"After reindexing: {df_combined.shape}")

# ============================================
# 5. Handle columns that are completely missing
# ============================================
# Check for columns that are all NaN
all_nan_cols = df_combined.columns[df_combined.isnull().all()].tolist()
if len(all_nan_cols) > 0:
    print(f"Found {len(all_nan_cols)} columns that are completely missing. Filling with 0.")
    df_combined[all_nan_cols] = 0

# ============================================
# 6. Impute remaining missing values with KNN
# ============================================
if df_combined.isnull().sum().sum() > 0:
    print("Imputing missing values with KNN (k=5)...")
    imputer = KNNImputer(n_neighbors=5)
    # Fit and transform the entire matrix
    imputed_array = imputer.fit_transform(df_combined)
    # Create a new DataFrame with same index and columns
    df_combined = pd.DataFrame(imputed_array, index=df_combined.index, columns=df_combined.columns)
    print("Imputation complete.")
else:
    print("No missing values found after filling all-NaN columns.")

# ============================================
# 7. Save as .npy and feature names
# ============================================
M_matrix = df_combined.values.astype(np.float32)
np.save(os.path.join(OUTPUT_DIR, "M_gbM_matrix.npy"), M_matrix)
print(f"\nSaved M_gbM_matrix.npy of shape {M_matrix.shape}")

feature_names = df_combined.columns.values
np.save(os.path.join(OUTPUT_DIR, "M_gbM_feature_names.npy"), feature_names)
print(f"Saved M_gbM_feature_names.npy with {len(feature_names)} features.")

# Optional sample CSV
df_combined.iloc[:10, :10].to_csv(os.path.join(OUTPUT_DIR, "M_gbM_matrix_sample.csv"))
print("Saved M_gbM_matrix_sample.csv (10x10).")

print("\n✅ gbM data preprocessing completed successfully.")