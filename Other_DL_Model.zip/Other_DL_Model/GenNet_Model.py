"""
GenNet Sparse Neural Network Regression Baseline

This script trains and evaluates a GenNet-style sparse neural network for
phenotype prediction.

Main features:
- GenNet-style sparse feature-to-gene connections
- Supports single-omics or integrated multi-omics input
- Uses a user-provided feature-to-gene mask
- Mean imputation within each training fold
- Variance filtering within each training fold
- Optional standardization within each training fold
- K-fold cross-validation
- Evaluation metrics: PCC, R2, RMSE, CCC
- Saves per-fold predictions, trained models, and summary metrics

Important:
    The mask must match the feature order of the input matrix.

    If using multiple omics files, they are concatenated in the order provided.
    Therefore, the mask rows must follow the same concatenated feature order.

Example:
    python gennet_regression_baseline.py \
        --omics G_matrix.npy T_matrix.npy M_gbM_matrix.npy \
        --omics-names G T gbM \
        --mask feature_to_gene_mask.npy \
        --phenotypes phenotypes.xlsx \
        --target DoR \
        --outdir results/GenNet/DoR \
        --epochs 100 \
        --batch-size 32 \
        --standardize
"""

import os
import argparse
import warnings
import random
import numpy as np
import pandas as pd

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import TensorDataset, DataLoader

from scipy.stats import pearsonr
from sklearn.model_selection import KFold
from sklearn.metrics import r2_score, mean_squared_error

warnings.filterwarnings("ignore")


# ============================================================
# Reproducibility
# ============================================================

def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


# ============================================================
# Data loading
# ============================================================

def load_matrix(file_path):
    """
    Load matrix from .npy, .csv, .tsv, or .xlsx file.

    Rows must represent samples/accessions.
    Columns must represent features.
    """
    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".npy":
        X = np.load(file_path)

    elif ext == ".csv":
        df = pd.read_csv(file_path)
        df = df.select_dtypes(include=[np.number])
        X = df.values

    elif ext == ".tsv":
        df = pd.read_csv(file_path, sep="\t")
        df = df.select_dtypes(include=[np.number])
        X = df.values

    elif ext in [".xlsx", ".xls"]:
        df = pd.read_excel(file_path)
        df = df.select_dtypes(include=[np.number])
        X = df.values

    else:
        raise ValueError(f"Unsupported matrix file format: {file_path}")

    return X.astype(np.float32)


def load_phenotype(file_path, target_col):
    """
    Load phenotype values from .csv or .xlsx file.
    """
    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".csv":
        df = pd.read_csv(file_path)

    elif ext in [".xlsx", ".xls"]:
        df = pd.read_excel(file_path)

    else:
        raise ValueError("Phenotype file must be .csv, .xlsx, or .xls")

    if target_col not in df.columns:
        raise ValueError(
            f"Target column '{target_col}' not found. "
            f"Available columns: {list(df.columns)}"
        )

    return df[target_col].values.astype(np.float32)


def load_mask(file_path):
    """
    Load feature-to-gene mask.

    Expected shape:
        number_of_features x number_of_genes

    Mask value:
        1 = connection exists
        0 = no connection
    """
    mask = load_matrix(file_path)
    mask = (mask > 0).astype(np.float32)
    return mask


# ============================================================
# Preprocessing
# ============================================================

def impute_train_test(X_train, X_test):
    """
    Mean imputation using training-set column means only.
    """
    col_mean = np.nanmean(X_train, axis=0)
    col_mean = np.where(np.isnan(col_mean), 0, col_mean)

    X_train = X_train.copy()
    X_test = X_test.copy()

    train_nan = np.where(np.isnan(X_train))
    test_nan = np.where(np.isnan(X_test))

    X_train[train_nan] = np.take(col_mean, train_nan[1])
    X_test[test_nan] = np.take(col_mean, test_nan[1])

    return X_train, X_test


def standardize_train_test(X_train, X_test):
    """
    Standardize features using training-set mean and standard deviation only.
    """
    mean = np.mean(X_train, axis=0)
    std = np.std(X_train, axis=0)

    std = np.where(std == 0, 1, std)

    X_train = (X_train - mean) / std
    X_test = (X_test - mean) / std

    return X_train.astype(np.float32), X_test.astype(np.float32)


def variance_filter_train_test(X_train, X_test, mask, threshold):
    """
    Apply variance filtering using training data only.
    The same retained features are used to filter the mask rows.
    """
    variances = np.var(X_train, axis=0)
    feature_keep = variances > threshold

    if feature_keep.sum() == 0:
        raise ValueError(
            "No features remained after variance filtering. "
            "Try lowering --variance-threshold."
        )

    X_train = X_train[:, feature_keep]
    X_test = X_test[:, feature_keep]
    mask = mask[feature_keep, :]

    # Remove genes with no connected features after filtering
    gene_keep = mask.sum(axis=0) > 0

    if gene_keep.sum() == 0:
        raise ValueError(
            "No genes remained after applying the feature mask. "
            "Check whether the mask matches the input feature order."
        )

    mask = mask[:, gene_keep]

    return X_train, X_test, mask, feature_keep.sum(), gene_keep.sum()


# ============================================================
# Metrics
# ============================================================

def safe_pcc(y_true, y_pred):
    """
    Pearson correlation coefficient.
    """
    if np.std(y_true) == 0 or np.std(y_pred) == 0:
        return np.nan

    pcc, _ = pearsonr(y_true, y_pred)
    return pcc


def rmse_score(y_true, y_pred):
    """
    Root mean squared error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))


def ccc_score(y_true, y_pred):
    """
    Concordance correlation coefficient.
    """
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    mean_true = np.mean(y_true)
    mean_pred = np.mean(y_pred)

    var_true = np.var(y_true)
    var_pred = np.var(y_pred)

    cov = np.mean((y_true - mean_true) * (y_pred - mean_pred))

    numerator = 2 * cov
    denominator = var_true + var_pred + (mean_true - mean_pred) ** 2

    if denominator == 0:
        return np.nan

    return numerator / denominator


# ============================================================
# GenNet model
# ============================================================

class SparseConnectedModule(nn.Module):
    """
    Sparse linear layer.

    The mask determines which input features are connected to which output units.

    Input:
        batch_size x input_size

    Output:
        batch_size x output_size

    Mask shape before transposition:
        input_size x output_size
    """

    def __init__(self, input_size, output_size, mask):
        super().__init__()

        if mask.shape != (input_size, output_size):
            raise ValueError(
                f"Mask shape must be ({input_size}, {output_size}), "
                f"but got {mask.shape}."
            )

        # F.linear expects weight shape: output_size x input_size
        mask_tensor = torch.tensor(mask.T, dtype=torch.float32)

        # register_buffer moves the mask automatically with model.to(device)
        self.register_buffer("mask", mask_tensor)

        self.weight = nn.Parameter(torch.empty(output_size, input_size))
        self.bias = nn.Parameter(torch.empty(output_size))

        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.weight)
        nn.init.zeros_(self.bias)

    def forward(self, x):
        masked_weight = self.weight * self.mask
        return F.linear(x, masked_weight, self.bias)


class GenNet(nn.Module):
    """
    GenNet-style sparse neural network for regression.

    Structure:
        input features → sparse feature-to-gene layer → ReLU → linear output layer

    Input shape:
        batch_size x number_of_features

    Output shape:
        batch_size x 1
    """

    def __init__(
        self,
        mask,
        dropout=0.0,
        positive_output=False
    ):
        super().__init__()

        input_size = mask.shape[0]
        gene_size = mask.shape[1]

        self.positive_output = positive_output

        self.feature_to_gene = SparseConnectedModule(
            input_size=input_size,
            output_size=gene_size,
            mask=mask
        )

        self.dropout = nn.Dropout(dropout)
        self.output_layer = nn.Linear(gene_size, 1)
        self.relu = nn.ReLU()

        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.output_layer.weight)
        nn.init.zeros_(self.output_layer.bias)

    def forward(self, x):
        x = self.feature_to_gene(x)
        x = self.relu(x)
        x = self.dropout(x)
        x = self.output_layer(x)

        if self.positive_output:
            x = self.relu(x)

        return x


# ============================================================
# Training and prediction
# ============================================================

def train_one_epoch(model, loader, optimizer, criterion, device):
    model.train()
    total_loss = 0.0

    for batch_x, batch_y in loader:
        batch_x = batch_x.to(device)
        batch_y = batch_y.to(device)

        optimizer.zero_grad()

        pred = model(batch_x)
        loss = criterion(pred, batch_y)

        loss.backward()
        optimizer.step()

        total_loss += loss.item() * batch_x.size(0)

    return total_loss / len(loader.dataset)


def predict(model, loader, device):
    model.eval()

    predictions = []
    true_values = []

    with torch.no_grad():
        for batch_x, batch_y in loader:
            batch_x = batch_x.to(device)

            pred = model(batch_x).cpu().numpy().reshape(-1)
            true = batch_y.cpu().numpy().reshape(-1)

            predictions.append(pred)
            true_values.append(true)

    predictions = np.concatenate(predictions)
    true_values = np.concatenate(true_values)

    return true_values, predictions


# ============================================================
# Main function
# ============================================================

def main(args):
    set_seed(args.random_state)

    os.makedirs(args.outdir, exist_ok=True)

    device = torch.device(
        "cuda" if torch.cuda.is_available() and not args.cpu else "cpu"
    )

    print("=" * 70)
    print("GenNet Sparse Neural Network Regression")
    print("=" * 70)
    print(f"Target trait: {args.target}")
    print(f"Phenotype file: {args.phenotypes}")
    print(f"Mask file: {args.mask}")
    print(f"Output directory: {args.outdir}")
    print(f"Device: {device}")
    print("=" * 70)

    # --------------------------------------------------------
    # Load and concatenate omics matrices
    # --------------------------------------------------------
    omics_names = args.omics_names

    if omics_names is None:
        omics_names = [f"omics_{i+1}" for i in range(len(args.omics))]

    if len(omics_names) != len(args.omics):
        raise ValueError("Number of --omics-names must match number of --omics files.")

    matrices = []

    print("\nLoading input matrices...")
    for name, path in zip(omics_names, args.omics):
        X_part = load_matrix(path)
        matrices.append(X_part)
        print(f"  {name}: {X_part.shape}")

    n_samples = matrices[0].shape[0]

    for name, X_part in zip(omics_names, matrices):
        if X_part.shape[0] != n_samples:
            raise ValueError(
                f"Sample count mismatch in {name}: "
                f"{X_part.shape[0]} samples, expected {n_samples}."
            )

    X = np.hstack(matrices).astype(np.float32)
    print(f"\nIntegrated input matrix: {X.shape}")

    # --------------------------------------------------------
    # Load phenotype and mask
    # --------------------------------------------------------
    y = load_phenotype(args.phenotypes, args.target)

    if X.shape[0] != len(y):
        raise ValueError(
            f"Sample count mismatch: input matrix has {X.shape[0]} samples, "
            f"but phenotype file has {len(y)} samples."
        )

    mask = load_mask(args.mask)

    if mask.shape[0] != X.shape[1]:
        raise ValueError(
            f"Mask row count must match number of input features. "
            f"Input features: {X.shape[1]}, mask rows: {mask.shape[0]}."
        )

    print(f"Phenotype vector: {y.shape}")
    print(f"Feature-to-gene mask: {mask.shape}")

    # --------------------------------------------------------
    # Cross-validation
    # --------------------------------------------------------
    kfold = KFold(
        n_splits=args.n_splits,
        shuffle=True,
        random_state=args.random_state
    )

    results = []
    all_predictions = []

    print("\nStarting cross-validation...")

    for fold, (train_idx, test_idx) in enumerate(kfold.split(X), start=1):
        print("\n" + "=" * 70)
        print(f"Fold {fold}/{args.n_splits}")
        print("=" * 70)

        X_train = X[train_idx]
        X_test = X[test_idx]

        y_train = y[train_idx]
        y_test = y[test_idx]

        # Imputation within fold
        X_train, X_test = impute_train_test(X_train, X_test)

        # Optional standardization within fold
        if args.standardize:
            X_train, X_test = standardize_train_test(X_train, X_test)

        # Variance filtering within fold
        X_train, X_test, fold_mask, n_features_kept, n_genes_kept = variance_filter_train_test(
            X_train,
            X_test,
            mask,
            args.variance_threshold
        )

        print(f"  Features kept: {n_features_kept:,}")
        print(f"  Gene units kept: {n_genes_kept:,}")

        # Convert to tensors
        X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
        X_test_tensor = torch.tensor(X_test, dtype=torch.float32)

        y_train_tensor = torch.tensor(y_train, dtype=torch.float32).view(-1, 1)
        y_test_tensor = torch.tensor(y_test, dtype=torch.float32).view(-1, 1)

        train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
        test_dataset = TensorDataset(X_test_tensor, y_test_tensor)

        train_loader = DataLoader(
            train_dataset,
            batch_size=args.batch_size,
            shuffle=True
        )

        test_loader = DataLoader(
            test_dataset,
            batch_size=args.batch_size,
            shuffle=False
        )

        # Build model
        model = GenNet(
            mask=fold_mask,
            dropout=args.dropout,
            positive_output=args.positive_output
        ).to(device)

        optimizer = torch.optim.Adam(
            model.parameters(),
            lr=args.learning_rate,
            weight_decay=args.weight_decay
        )

        criterion = nn.MSELoss()

        best_loss = np.inf
        best_state = None
        patience_counter = 0

        # ----------------------------------------------------
        # Training
        # ----------------------------------------------------
        for epoch in range(1, args.epochs + 1):
            train_loss = train_one_epoch(
                model,
                train_loader,
                optimizer,
                criterion,
                device
            )

            if train_loss < best_loss:
                best_loss = train_loss
                best_state = model.state_dict()
                patience_counter = 0
            else:
                patience_counter += 1

            if epoch % args.print_every == 0 or epoch == 1:
                print(
                    f"  Epoch {epoch:03d}/{args.epochs} | "
                    f"Loss: {train_loss:.6f}"
                )

            if args.early_stopping > 0 and patience_counter >= args.early_stopping:
                print(f"  Early stopping at epoch {epoch}")
                break

        if best_state is not None:
            model.load_state_dict(best_state)

        # ----------------------------------------------------
        # Testing
        # ----------------------------------------------------
        y_true, y_pred = predict(model, test_loader, device)

        r2 = r2_score(y_true, y_pred)
        pcc = safe_pcc(y_true, y_pred)
        rmse = rmse_score(y_true, y_pred)
        ccc = ccc_score(y_true, y_pred)

        print(f"  R2:   {r2:.4f}")
        print(f"  PCC:  {pcc:.4f}")
        print(f"  RMSE: {rmse:.4f}")
        print(f"  CCC:  {ccc:.4f}")

        # Save predictions
        pred_df = pd.DataFrame({
            "fold": fold,
            "sample_index": test_idx,
            "true": y_true,
            "predicted": y_pred
        })

        pred_path = os.path.join(args.outdir, f"predictions_fold_{fold}.csv")
        pred_df.to_csv(pred_path, index=False)

        all_predictions.append(pred_df)

        # Save model
        if args.save_models:
            model_path = os.path.join(args.outdir, f"gennet_model_fold_{fold}.pt")
            torch.save(model.state_dict(), model_path)

        # Store metrics
        results.append({
            "fold": fold,
            "r2": r2,
            "pcc": pcc,
            "rmse": rmse,
            "ccc": ccc,
            "features_kept": n_features_kept,
            "gene_units_kept": n_genes_kept
        })

    # --------------------------------------------------------
    # Save final results
    # --------------------------------------------------------
    results_df = pd.DataFrame(results)

    metrics_path = os.path.join(args.outdir, "per_fold_metrics.csv")
    results_df.to_csv(metrics_path, index=False)

    all_pred_df = pd.concat(all_predictions, axis=0)
    all_pred_path = os.path.join(args.outdir, "all_predictions.csv")
    all_pred_df.to_csv(all_pred_path, index=False)

    summary = pd.DataFrame({
        "metric": ["R2", "PCC", "RMSE", "CCC"],
        "mean": [
            results_df["r2"].mean(),
            results_df["pcc"].mean(),
            results_df["rmse"].mean(),
            results_df["ccc"].mean()
        ],
        "std": [
            results_df["r2"].std(),
            results_df["pcc"].std(),
            results_df["rmse"].std(),
            results_df["ccc"].std()
        ]
    })

    summary_path = os.path.join(args.outdir, "summary_metrics.csv")
    summary.to_csv(summary_path, index=False)

    print("\n" + "=" * 70)
    print("Final Summary")
    print("=" * 70)
    print(summary.to_string(index=False))

    print("\nSaved files:")
    print(f"  Per-fold metrics: {metrics_path}")
    print(f"  Summary metrics:  {summary_path}")
    print(f"  All predictions:  {all_pred_path}")
    print("=" * 70)


# ============================================================
# Command-line arguments
# ============================================================

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="GenNet sparse neural network regression for phenotype prediction."
    )

    parser.add_argument(
        "--omics",
        nargs="+",
        required=True,
        help="Input matrix file(s). Example: G_matrix.npy T_matrix.npy M_gbM_matrix.npy"
    )

    parser.add_argument(
        "--omics-names",
        nargs="+",
        default=None,
        help="Names of input layers. Example: G T gbM"
    )

    parser.add_argument(
        "--mask",
        required=True,
        help="Feature-to-gene mask file. Shape must be input_features x genes."
    )

    parser.add_argument(
        "--phenotypes",
        required=True,
        help="Path to phenotype file. Example: phenotypes.xlsx"
    )

    parser.add_argument(
        "--target",
        required=True,
        help="Target phenotype column name. Example: DoR"
    )

    parser.add_argument(
        "--outdir",
        required=True,
        help="Directory to save results."
    )

    parser.add_argument(
        "--n-splits",
        type=int,
        default=10,
        help="Number of cross-validation folds. Default: 10"
    )

    parser.add_argument(
        "--epochs",
        type=int,
        default=100,
        help="Number of training epochs. Default: 100"
    )

    parser.add_argument(
        "--batch-size",
        type=int,
        default=32,
        help="Batch size. Default: 32"
    )

    parser.add_argument(
        "--learning-rate",
        type=float,
        default=0.001,
        help="Learning rate. Default: 0.001"
    )

    parser.add_argument(
        "--weight-decay",
        type=float,
        default=0.0,
        help="Weight decay. Default: 0.0"
    )

    parser.add_argument(
        "--variance-threshold",
        type=float,
        default=0.0,
        help="Feature variance threshold. Default: 0.0"
    )

    parser.add_argument(
        "--dropout",
        type=float,
        default=0.0,
        help="Dropout after the sparse gene layer. Default: 0.0"
    )

    parser.add_argument(
        "--standardize",
        action="store_true",
        help="Apply training-fold standardization."
    )

    parser.add_argument(
        "--positive-output",
        action="store_true",
        help="Apply ReLU to the final output. Use only when phenotype values are non-negative."
    )

    parser.add_argument(
        "--early-stopping",
        type=int,
        default=0,
        help="Stop training if loss does not improve for this many epochs. Default: 0 disables it."
    )

    parser.add_argument(
        "--print-every",
        type=int,
        default=10,
        help="Print training status every N epochs. Default: 10"
    )

    parser.add_argument(
        "--random-state",
        type=int,
        default=42,
        help="Random seed. Default: 42"
    )

    parser.add_argument(
        "--save-models",
        action="store_true",
        help="Save trained model for each fold."
    )

    parser.add_argument(
        "--cpu",
        action="store_true",
        help="Force training on CPU."
    )

    args = parser.parse_args()
    main(args)