"""
DNNGP Regression Baseline for Phenotype Prediction

This script trains and evaluates a DNNGP-style convolutional neural network
for continuous phenotype prediction.

Main features:
- DNNGP model only
- Supports .npy, .csv, .tsv, .xlsx feature matrices
- Supports .csv and .xlsx phenotype files
- K-fold cross-validation
- Mean imputation within each training fold
- Variance filtering within each training fold
- Evaluation metrics: PCC, R2, RMSE, CCC
- Saves per-fold predictions, trained models, and summary metrics

Example:
    python dnngp_regression_baseline.py \
        --features G_matrix.npy \
        --phenotypes phenotypes.xlsx \
        --target DoR \
        --outdir results/DNNGP/DoR \
        --epochs 100 \
        --batch-size 32
"""

import os
import argparse
import warnings
import random
import math
import numpy as np
import pandas as pd

import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader

from scipy.stats import pearsonr
from sklearn.model_selection import KFold
from sklearn.metrics import r2_score, mean_squared_error

warnings.filterwarnings("ignore")


# ============================================================
# Reproducibility
# ============================================================

def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


# ============================================================
# Data loading
# ============================================================

def load_matrix(file_path):
    """
    Load feature matrix from .npy, .csv, .tsv, or .xlsx file.

    Rows must represent samples/accessions.
    Columns must represent features.
    """
    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".npy":
        X = np.load(file_path)

    elif ext == ".csv":
        df = pd.read_csv(file_path)
        df = df.select_dtypes(include=[np.number])
        X = df.values

    elif ext == ".tsv":
        df = pd.read_csv(file_path, sep="\t")
        df = df.select_dtypes(include=[np.number])
        X = df.values

    elif ext in [".xlsx", ".xls"]:
        df = pd.read_excel(file_path)
        df = df.select_dtypes(include=[np.number])
        X = df.values

    else:
        raise ValueError(f"Unsupported feature file format: {file_path}")

    return X.astype(np.float32)


def load_phenotype(file_path, target_col):
    """
    Load phenotype values from .csv or .xlsx file.
    """
    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".csv":
        df = pd.read_csv(file_path)

    elif ext in [".xlsx", ".xls"]:
        df = pd.read_excel(file_path)

    else:
        raise ValueError("Phenotype file must be .csv, .xlsx, or .xls")

    if target_col not in df.columns:
        raise ValueError(
            f"Target column '{target_col}' not found. "
            f"Available columns: {list(df.columns)}"
        )

    y = df[target_col].values.astype(np.float32)
    return y


# ============================================================
# Preprocessing
# ============================================================

def impute_train_test(X_train, X_test):
    """
    Mean imputation using training-set column means only.
    """
    col_mean = np.nanmean(X_train, axis=0)
    col_mean = np.where(np.isnan(col_mean), 0, col_mean)

    X_train = X_train.copy()
    X_test = X_test.copy()

    train_nan = np.where(np.isnan(X_train))
    test_nan = np.where(np.isnan(X_test))

    X_train[train_nan] = np.take(col_mean, train_nan[1])
    X_test[test_nan] = np.take(col_mean, test_nan[1])

    return X_train, X_test


def variance_filter_train_test(X_train, X_test, threshold):
    """
    Remove low-variance features using training data only.
    """
    variances = np.var(X_train, axis=0)
    keep = variances > threshold

    if keep.sum() == 0:
        raise ValueError(
            "No features remained after variance filtering. "
            "Try lowering --variance-threshold."
        )

    return X_train[:, keep], X_test[:, keep], keep.sum()


def reshape_for_dnngp(X, input_channels=24):
    """
    Convert a 2D feature matrix into a 4D tensor for DNNGP.

    Original shape:
        samples x features

    Output shape:
        samples x input_channels x grid_size x grid_size

    If the number of features is not exactly input_channels * grid_size * grid_size,
    the feature vector is padded with zeros.
    """
    n_samples, n_features = X.shape

    grid_size = math.ceil(math.sqrt(math.ceil(n_features / input_channels)))
    required_features = input_channels * grid_size * grid_size

    if required_features > n_features:
        padding = required_features - n_features
        X = np.pad(
            X,
            pad_width=((0, 0), (0, padding)),
            mode="constant",
            constant_values=0
        )

    X = X.reshape(n_samples, input_channels, grid_size, grid_size)

    return X.astype(np.float32), grid_size, required_features


# ============================================================
# Metrics
# ============================================================

def safe_pcc(y_true, y_pred):
    """
    Pearson correlation coefficient.
    """
    if np.std(y_true) == 0 or np.std(y_pred) == 0:
        return np.nan

    pcc, _ = pearsonr(y_true, y_pred)
    return pcc


def rmse_score(y_true, y_pred):
    """
    Root mean squared error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))


def ccc_score(y_true, y_pred):
    """
    Concordance correlation coefficient.
    """
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    mean_true = np.mean(y_true)
    mean_pred = np.mean(y_pred)

    var_true = np.var(y_true)
    var_pred = np.var(y_pred)

    cov = np.mean((y_true - mean_true) * (y_pred - mean_pred))

    numerator = 2 * cov
    denominator = var_true + var_pred + (mean_true - mean_pred) ** 2

    if denominator == 0:
        return np.nan

    return numerator / denominator


# ============================================================
# DNNGP model
# ============================================================

class DNNGP(nn.Module):
    """
    DNNGP-style 2D convolutional neural network for regression.

    Input shape:
        batch_size x 24 x grid_size x grid_size

    Output shape:
        batch_size x 1
    """

    def __init__(
        self,
        grid_size,
        input_channels=24,
        conv_channels=64,
        hidden_dim=64,
        dropout=0.10,
        positive_output=False
    ):
        super().__init__()

        self.positive_output = positive_output

        self.conv1 = nn.Conv2d(
            in_channels=input_channels,
            out_channels=conv_channels,
            kernel_size=3,
            stride=1,
            padding=1
        )

        self.dropout1 = nn.Dropout(dropout)
        self.batch_norm1 = nn.BatchNorm2d(conv_channels)

        self.conv2 = nn.Conv2d(
            in_channels=conv_channels,
            out_channels=conv_channels,
            kernel_size=3,
            stride=1,
            padding=1
        )

        self.dropout2 = nn.Dropout(dropout)
        self.batch_norm2 = nn.BatchNorm2d(conv_channels)

        self.conv3 = nn.Conv2d(
            in_channels=conv_channels,
            out_channels=conv_channels,
            kernel_size=3,
            stride=1,
            padding=1
        )

        self.flatten = nn.Flatten()

        self.fc1 = nn.Linear(conv_channels * grid_size * grid_size, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, 1)

        self.relu = nn.ReLU()

        self._initialize_weights()

    def _initialize_weights(self):
        """
        Initialize model weights.
        """
        for module in self.modules():
            if isinstance(module, nn.Conv2d):
                nn.init.kaiming_normal_(module.weight, nonlinearity="relu")
                if module.bias is not None:
                    nn.init.zeros_(module.bias)

            elif isinstance(module, nn.Linear):
                nn.init.xavier_normal_(module.weight)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)

    def forward(self, x):
        x = self.relu(self.conv1(x))
        x = self.dropout1(x)
        x = self.batch_norm1(x)

        x = self.relu(self.conv2(x))
        x = self.dropout2(x)
        x = self.batch_norm2(x)

        x = self.relu(self.conv3(x))

        x = self.flatten(x)

        x = self.relu(self.fc1(x))
        x = self.fc2(x)

        if self.positive_output:
            x = self.relu(x)

        return x


# ============================================================
# Training and prediction
# ============================================================

def train_one_epoch(model, loader, optimizer, criterion, device):
    model.train()
    total_loss = 0.0

    for batch_x, batch_y in loader:
        batch_x = batch_x.to(device)
        batch_y = batch_y.to(device)

        optimizer.zero_grad()

        pred = model(batch_x)
        loss = criterion(pred, batch_y)

        loss.backward()
        optimizer.step()

        total_loss += loss.item() * batch_x.size(0)

    return total_loss / len(loader.dataset)


def predict(model, loader, device):
    model.eval()

    predictions = []
    true_values = []

    with torch.no_grad():
        for batch_x, batch_y in loader:
            batch_x = batch_x.to(device)

            pred = model(batch_x).cpu().numpy().reshape(-1)
            true = batch_y.cpu().numpy().reshape(-1)

            predictions.append(pred)
            true_values.append(true)

    predictions = np.concatenate(predictions)
    true_values = np.concatenate(true_values)

    return true_values, predictions


# ============================================================
# Main function
# ============================================================

def main(args):
    set_seed(args.random_state)

    os.makedirs(args.outdir, exist_ok=True)

    device = torch.device(
        "cuda" if torch.cuda.is_available() and not args.cpu else "cpu"
    )

    print("=" * 70)
    print("DNNGP Regression Baseline")
    print("=" * 70)
    print(f"Target trait: {args.target}")
    print(f"Feature file: {args.features}")
    print(f"Phenotype file: {args.phenotypes}")
    print(f"Output directory: {args.outdir}")
    print(f"Device: {device}")
    print("=" * 70)

    # --------------------------------------------------------
    # Load data
    # --------------------------------------------------------
    X = load_matrix(args.features)
    y = load_phenotype(args.phenotypes, args.target)

    if X.shape[0] != len(y):
        raise ValueError(
            f"Sample count mismatch: feature matrix has {X.shape[0]} samples, "
            f"but phenotype file has {len(y)} samples."
        )

    print(f"\nFeature matrix shape: {X.shape}")
    print(f"Phenotype vector shape: {y.shape}")

    # --------------------------------------------------------
    # Cross-validation
    # --------------------------------------------------------
    kfold = KFold(
        n_splits=args.n_splits,
        shuffle=True,
        random_state=args.random_state
    )

    results = []
    all_predictions = []

    for fold, (train_idx, test_idx) in enumerate(kfold.split(X), start=1):
        print("\n" + "=" * 70)
        print(f"Fold {fold}/{args.n_splits}")
        print("=" * 70)

        X_train = X[train_idx]
        X_test = X[test_idx]

        y_train = y[train_idx]
        y_test = y[test_idx]

        # Imputation within fold
        X_train, X_test = impute_train_test(X_train, X_test)

        # Variance filtering within fold
        X_train, X_test, n_kept = variance_filter_train_test(
            X_train,
            X_test,
            args.variance_threshold
        )

        print(f"  Features kept: {n_kept:,}")

        # Reshape feature vectors into 2D maps
        X_train, grid_size, padded_features = reshape_for_dnngp(
            X_train,
            input_channels=args.input_channels
        )

        X_test, _, _ = reshape_for_dnngp(
            X_test,
            input_channels=args.input_channels
        )

        print(f"  Grid size: {grid_size} x {grid_size}")
        print(f"  Padded feature length: {padded_features:,}")
        print(f"  Training tensor: {X_train.shape}")
        print(f"  Testing tensor:  {X_test.shape}")

        # Convert to tensors
        X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
        X_test_tensor = torch.tensor(X_test, dtype=torch.float32)

        y_train_tensor = torch.tensor(y_train, dtype=torch.float32).view(-1, 1)
        y_test_tensor = torch.tensor(y_test, dtype=torch.float32).view(-1, 1)

        train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
        test_dataset = TensorDataset(X_test_tensor, y_test_tensor)

        train_loader = DataLoader(
            train_dataset,
            batch_size=args.batch_size,
            shuffle=True
        )

        test_loader = DataLoader(
            test_dataset,
            batch_size=args.batch_size,
            shuffle=False
        )

        # Build model
        model = DNNGP(
            grid_size=grid_size,
            input_channels=args.input_channels,
            conv_channels=args.conv_channels,
            hidden_dim=args.hidden_dim,
            dropout=args.dropout,
            positive_output=args.positive_output
        ).to(device)

        optimizer = torch.optim.Adam(
            model.parameters(),
            lr=args.learning_rate,
            weight_decay=args.weight_decay
        )

        criterion = nn.MSELoss()

        best_loss = np.inf
        best_state = None
        patience_counter = 0

        # ----------------------------------------------------
        # Training
        # ----------------------------------------------------
        for epoch in range(1, args.epochs + 1):
            train_loss = train_one_epoch(
                model,
                train_loader,
                optimizer,
                criterion,
                device
            )

            if train_loss < best_loss:
                best_loss = train_loss
                best_state = model.state_dict()
                patience_counter = 0
            else:
                patience_counter += 1

            if epoch % args.print_every == 0 or epoch == 1:
                print(
                    f"  Epoch {epoch:03d}/{args.epochs} | "
                    f"Loss: {train_loss:.6f}"
                )

            if args.early_stopping > 0 and patience_counter >= args.early_stopping:
                print(f"  Early stopping at epoch {epoch}")
                break

        if best_state is not None:
            model.load_state_dict(best_state)

        # ----------------------------------------------------
        # Testing
        # ----------------------------------------------------
        y_true, y_pred = predict(model, test_loader, device)

        r2 = r2_score(y_true, y_pred)
        pcc = safe_pcc(y_true, y_pred)
        rmse = rmse_score(y_true, y_pred)
        ccc = ccc_score(y_true, y_pred)

        print(f"  R2:   {r2:.4f}")
        print(f"  PCC:  {pcc:.4f}")
        print(f"  RMSE: {rmse:.4f}")
        print(f"  CCC:  {ccc:.4f}")

        # Save predictions for this fold
        pred_df = pd.DataFrame({
            "fold": fold,
            "sample_index": test_idx,
            "true": y_true,
            "predicted": y_pred
        })

        pred_path = os.path.join(args.outdir, f"predictions_fold_{fold}.csv")
        pred_df.to_csv(pred_path, index=False)

        all_predictions.append(pred_df)

        # Save model
        if args.save_models:
            model_path = os.path.join(args.outdir, f"dnngp_model_fold_{fold}.pt")
            torch.save(model.state_dict(), model_path)

        # Store metrics
        results.append({
            "fold": fold,
            "r2": r2,
            "pcc": pcc,
            "rmse": rmse,
            "ccc": ccc,
            "features_kept": n_kept,
            "grid_size": grid_size,
            "padded_feature_length": padded_features
        })

    # --------------------------------------------------------
    # Save final results
    # --------------------------------------------------------
    results_df = pd.DataFrame(results)

    metrics_path = os.path.join(args.outdir, "per_fold_metrics.csv")
    results_df.to_csv(metrics_path, index=False)

    all_pred_df = pd.concat(all_predictions, axis=0)
    all_pred_path = os.path.join(args.outdir, "all_predictions.csv")
    all_pred_df.to_csv(all_pred_path, index=False)

    summary = pd.DataFrame({
        "metric": ["R2", "PCC", "RMSE", "CCC"],
        "mean": [
            results_df["r2"].mean(),
            results_df["pcc"].mean(),
            results_df["rmse"].mean(),
            results_df["ccc"].mean()
        ],
        "std": [
            results_df["r2"].std(),
            results_df["pcc"].std(),
            results_df["rmse"].std(),
            results_df["ccc"].std()
        ]
    })

    summary_path = os.path.join(args.outdir, "summary_metrics.csv")
    summary.to_csv(summary_path, index=False)

    print("\n" + "=" * 70)
    print("Final Summary")
    print("=" * 70)
    print(summary.to_string(index=False))

    print("\nSaved files:")
    print(f"  Per-fold metrics: {metrics_path}")
    print(f"  Summary metrics:  {summary_path}")
    print(f"  All predictions:  {all_pred_path}")
    print("=" * 70)


# ============================================================
# Command-line arguments
# ============================================================

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="DNNGP regression baseline for phenotype prediction."
    )

    parser.add_argument(
        "--features",
        required=True,
        help="Path to feature matrix. Example: G_matrix.npy"
    )

    parser.add_argument(
        "--phenotypes",
        required=True,
        help="Path to phenotype file. Example: phenotypes.xlsx"
    )

    parser.add_argument(
        "--target",
        required=True,
        help="Target phenotype column name. Example: DoR"
    )

    parser.add_argument(
        "--outdir",
        required=True,
        help="Directory to save results."
    )

    parser.add_argument(
        "--n-splits",
        type=int,
        default=10,
        help="Number of cross-validation folds. Default: 10"
    )

    parser.add_argument(
        "--epochs",
        type=int,
        default=100,
        help="Number of training epochs. Default: 100"
    )

    parser.add_argument(
        "--batch-size",
        type=int,
        default=32,
        help="Batch size. Default: 32"
    )

    parser.add_argument(
        "--learning-rate",
        type=float,
        default=0.001,
        help="Learning rate. Default: 0.001"
    )

    parser.add_argument(
        "--weight-decay",
        type=float,
        default=0.0,
        help="Weight decay. Default: 0.0"
    )

    parser.add_argument(
        "--variance-threshold",
        type=float,
        default=0.0,
        help="Feature variance threshold. Default: 0.0"
    )

    parser.add_argument(
        "--input-channels",
        type=int,
        default=24,
        help="Number of input channels after reshaping. Default: 24"
    )

    parser.add_argument(
        "--conv-channels",
        type=int,
        default=64,
        help="Number of convolutional output channels. Default: 64"
    )

    parser.add_argument(
        "--hidden-dim",
        type=int,
        default=64,
        help="Hidden dimension of the fully connected layer. Default: 64"
    )

    parser.add_argument(
        "--dropout",
        type=float,
        default=0.10,
        help="Dropout rate. Default: 0.10"
    )

    parser.add_argument(
        "--positive-output",
        action="store_true",
        help="Apply ReLU to the final output. Use only when phenotype values are non-negative."
    )

    parser.add_argument(
        "--early-stopping",
        type=int,
        default=0,
        help="Stop training if loss does not improve for this many epochs. Default: 0 disables it."
    )

    parser.add_argument(
        "--print-every",
        type=int,
        default=10,
        help="Print training status every N epochs. Default: 10"
    )

    parser.add_argument(
        "--random-state",
        type=int,
        default=42,
        help="Random seed. Default: 42"
    )

    parser.add_argument(
        "--save-models",
        action="store_true",
        help="Save trained model for each fold."
    )

    parser.add_argument(
        "--cpu",
        action="store_true",
        help="Force training on CPU."
    )

    args = parser.parse_args()
    main(args)