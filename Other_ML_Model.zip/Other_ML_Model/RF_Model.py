"""
Random Forest Regression Baseline for Phenotype Prediction

This script trains and evaluates a Random Forest regression model using SNP or
other feature data loaded through the Datasets function.

Main features:
- Random Forest regression only
- K-fold cross-validation
- Supports an optional predefined random index file
- Evaluation metrics: R2, PCC, RMSE, CCC
- Saves prediction results and per-fold metrics

Example:
    python rf_regression_baseline.py \
        --data-type snp \
        --phenotype HeadingDate \
        --labelpath frns_frnt_match.csv \
        --random-index random_index_HeadingDate.txt \
        --outdir results/RF_HeadingDate
"""

import os
import argparse
import warnings
import numpy as np
import pandas as pd
import joblib

from dataset import Datasets

from scipy.stats import pearsonr
from sklearn.model_selection import KFold
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error

warnings.filterwarnings("ignore")


# ============================================================
# Metric functions
# ============================================================

def safe_pcc(y_true, y_pred):
    """
    Pearson correlation coefficient.
    Returns NaN if the value cannot be calculated.
    """
    if np.std(y_true) == 0 or np.std(y_pred) == 0:
        return np.nan

    pcc, _ = pearsonr(y_true, y_pred)
    return pcc


def rmse_score(y_true, y_pred):
    """
    Root mean squared error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))


def ccc_score(y_true, y_pred):
    """
    Concordance correlation coefficient.
    """
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    mean_true = np.mean(y_true)
    mean_pred = np.mean(y_pred)

    var_true = np.var(y_true)
    var_pred = np.var(y_pred)

    cov = np.mean((y_true - mean_true) * (y_pred - mean_pred))

    numerator = 2 * cov
    denominator = var_true + var_pred + (mean_true - mean_pred) ** 2

    if denominator == 0:
        return np.nan

    return numerator / denominator


# ============================================================
# Main function
# ============================================================

def main(args):
    os.makedirs(args.outdir, exist_ok=True)

    print("=" * 70)
    print("Random Forest Regression Baseline")
    print("=" * 70)
    print(f"Data type: {args.data_type}")
    print(f"Phenotype: {args.phenotype}")
    print(f"Label file: {args.labelpath}")
    print(f"Output directory: {args.outdir}")
    print("=" * 70)

    # --------------------------------------------------------
    # Load data
    # --------------------------------------------------------
    print("\nLoading data...")

    datas, labels = Datasets(
        type=args.data_type,
        phnoe=args.phenotype,
        labelpath=args.labelpath
    )

    data = np.asarray(datas, dtype=np.float32)
    label = np.asarray(labels[0], dtype=np.float32)

    print(f"Original data shape: {data.shape}")
    print(f"Original label shape: {label.shape}")

    if data.shape[0] != len(label):
        raise ValueError(
            f"Sample count mismatch: data has {data.shape[0]} samples, "
            f"but labels have {len(label)} samples."
        )

    # --------------------------------------------------------
    # Apply predefined random order, if provided
    # --------------------------------------------------------
    if args.random_index is not None:
        print(f"\nApplying random index from: {args.random_index}")

        random_permutation = np.array(
            pd.read_csv(args.random_index, header=None, sep="\t")
        ).flatten()

        data = data[random_permutation]
        label = label[random_permutation]

    n_samples = data.shape[0]
    print(f"\nTotal samples: {n_samples}")

    # --------------------------------------------------------
    # Random Forest parameters
    # --------------------------------------------------------
    rf_params = {
        "n_estimators": args.n_estimators,
        "max_depth": args.max_depth,
        "max_features": args.max_features,
        "min_samples_split": args.min_samples_split,
        "min_samples_leaf": args.min_samples_leaf,
        "random_state": args.random_state,
        "n_jobs": args.n_jobs,
    }

    print("\nRandom Forest parameters:")
    for key, value in rf_params.items():
        print(f"  {key}: {value}")

    # --------------------------------------------------------
    # K-fold cross-validation
    # --------------------------------------------------------
    kfold = KFold(
        n_splits=args.n_splits,
        shuffle=False
    )

    results = []
    all_predictions = []

    print("\nStarting cross-validation...")

    for fold, (train_idx, test_idx) in enumerate(kfold.split(data), start=1):
        print("\n" + "=" * 70)
        print(f"Fold {fold}/{args.n_splits}")
        print("=" * 70)

        train_data = data[train_idx]
        train_label = label[train_idx]

        test_data = data[test_idx]
        test_label = label[test_idx]

        print(f"  Training data: {train_data.shape}")
        print(f"  Testing data:  {test_data.shape}")

        # ----------------------------------------------------
        # Train Random Forest
        # ----------------------------------------------------
        model = RandomForestRegressor(**rf_params)
        model.fit(train_data, train_label)

        # ----------------------------------------------------
        # Predict
        # ----------------------------------------------------
        y_pred = model.predict(test_data)

        # ----------------------------------------------------
        # Evaluation
        # ----------------------------------------------------
        r2 = r2_score(test_label, y_pred)
        pcc = safe_pcc(test_label, y_pred)
        rmse = rmse_score(test_label, y_pred)
        ccc = ccc_score(test_label, y_pred)

        print(f"  R2:   {r2:.4f}")
        print(f"  PCC:  {pcc:.4f}")
        print(f"  RMSE: {rmse:.4f}")
        print(f"  CCC:  {ccc:.4f}")

        # ----------------------------------------------------
        # Save fold predictions
        # ----------------------------------------------------
        pred_df = pd.DataFrame({
            "fold": fold,
            "sample_index": test_idx,
            "true": test_label,
            "predicted": y_pred
        })

        pred_path = os.path.join(args.outdir, f"predictions_fold_{fold}.csv")
        pred_df.to_csv(pred_path, index=False)

        all_predictions.append(pred_df)

        # ----------------------------------------------------
        # Save model
        # ----------------------------------------------------
        if args.save_models:
            model_path = os.path.join(args.outdir, f"rf_model_fold_{fold}.joblib")
            joblib.dump(model, model_path)

        # ----------------------------------------------------
        # Store metrics
        # ----------------------------------------------------
        results.append({
            "fold": fold,
            "r2": r2,
            "pcc": pcc,
            "rmse": rmse,
            "ccc": ccc
        })

    # --------------------------------------------------------
    # Save all predictions
    # --------------------------------------------------------
    all_pred_df = pd.concat(all_predictions, axis=0)
    all_pred_path = os.path.join(args.outdir, f"{args.phenotype}_RF_predictions.csv")
    all_pred_df.to_csv(all_pred_path, index=False)

    # --------------------------------------------------------
    # Save per-fold metrics
    # --------------------------------------------------------
    results_df = pd.DataFrame(results)
    metrics_path = os.path.join(args.outdir, f"{args.phenotype}_RF_per_fold_metrics.csv")
    results_df.to_csv(metrics_path, index=False)

    # --------------------------------------------------------
    # Save summary metrics
    # --------------------------------------------------------
    summary = pd.DataFrame({
        "metric": ["R2", "PCC", "RMSE", "CCC"],
        "mean": [
            results_df["r2"].mean(),
            results_df["pcc"].mean(),
            results_df["rmse"].mean(),
            results_df["ccc"].mean()
        ],
        "std": [
            results_df["r2"].std(),
            results_df["pcc"].std(),
            results_df["rmse"].std(),
            results_df["ccc"].std()
        ]
    })

    summary_path = os.path.join(args.outdir, f"{args.phenotype}_RF_summary_metrics.csv")
    summary.to_csv(summary_path, index=False)

    print("\n" + "=" * 70)
    print("Final Summary")
    print("=" * 70)
    print(summary.to_string(index=False))

    print("\nSaved files:")
    print(f"  Predictions:      {all_pred_path}")
    print(f"  Per-fold metrics: {metrics_path}")
    print(f"  Summary metrics:  {summary_path}")
    print("=" * 70)


# ============================================================
# Command-line arguments
# ============================================================

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Random Forest regression baseline for phenotype prediction."
    )

    parser.add_argument(
        "--data-type",
        default="snp",
        help="Input data type used by Datasets function. Default: snp"
    )

    parser.add_argument(
        "--phenotype",
        required=True,
        help="Phenotype name. Example: HeadingDate"
    )

    parser.add_argument(
        "--labelpath",
        required=True,
        help="Path to phenotype/label file. Example: frns_frnt_match.csv"
    )

    parser.add_argument(
        "--random-index",
        default=None,
        help="Optional path to predefined random index file."
    )

    parser.add_argument(
        "--outdir",
        required=True,
        help="Directory to save results."
    )

    parser.add_argument(
        "--n-splits",
        type=int,
        default=10,
        help="Number of cross-validation folds. Default: 10"
    )

    parser.add_argument(
        "--n-estimators",
        type=int,
        default=100,
        help="Number of trees. Default: 100"
    )

    parser.add_argument(
        "--max-depth",
        type=int,
        default=20,
        help="Maximum tree depth. Default: 20"
    )

    parser.add_argument(
        "--max-features",
        default="sqrt",
        help="Number of features considered at each split. Default: sqrt"
    )

    parser.add_argument(
        "--min-samples-split",
        type=int,
        default=2,
        help="Minimum samples required to split an internal node. Default: 2"
    )

    parser.add_argument(
        "--min-samples-leaf",
        type=int,
        default=1,
        help="Minimum samples required at a leaf node. Default: 1"
    )

    parser.add_argument(
        "--random-state",
        type=int,
        default=42,
        help="Random seed. Default: 42"
    )

    parser.add_argument(
        "--n-jobs",
        type=int,
        default=-1,
        help="Number of CPU cores. Default: -1 uses all available cores"
    )

    parser.add_argument(
        "--save-models",
        action="store_true",
        help="Save the trained model for each fold."
    )

    args = parser.parse_args()
    main(args)