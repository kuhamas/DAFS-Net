"""
Random Forest Multi-Omics Regression Baseline

This script trains and evaluates a Random Forest regression model using one or more
omics feature matrices, such as genomic SNPs, transcriptomic expression, and
gene-body methylation data.

Main features:
- Supports single-omics or multi-omics input
- Integrates multiple omics layers by feature concatenation
- Mean imputation is performed within each training fold
- Variance filtering is performed within each training fold
- K-fold cross-validation
- Evaluation metrics: PCC, RMSE, CCC
- Saves per-fold predictions, trained models, and summary metrics

Example:
    python rf_multiomics_regression.py \
        --omics G_matrix.npy T_matrix.npy M_gbM_matrix.npy \
        --omics-names G T gbM \
        --phenotypes phenotypes.xlsx \
        --target DoR \
        --outdir results/RF_Model/DoR
"""

import os
import argparse
import warnings
import numpy as np
import pandas as pd
import joblib

from scipy.stats import pearsonr
from sklearn.model_selection import KFold
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error

warnings.filterwarnings("ignore")


# ============================================================
# Utility functions
# ============================================================

def load_matrix(file_path):
    """
    Load a feature matrix from .npy, .csv, .tsv, or .xlsx file.

    Rows must represent samples/accessions.
    Columns must represent features.

    For CSV/Excel files, non-numeric columns are ignored.
    """
    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".npy":
        X = np.load(file_path)

    elif ext == ".csv":
        df = pd.read_csv(file_path)
        df = df.select_dtypes(include=[np.number])
        X = df.values

    elif ext == ".tsv":
        df = pd.read_csv(file_path, sep="\t")
        df = df.select_dtypes(include=[np.number])
        X = df.values

    elif ext in [".xlsx", ".xls"]:
        df = pd.read_excel(file_path)
        df = df.select_dtypes(include=[np.number])
        X = df.values

    else:
        raise ValueError(f"Unsupported file format: {file_path}")

    return X.astype(np.float32)


def load_phenotype(file_path, target_col):
    """
    Load phenotype values from CSV or Excel file.
    """
    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".csv":
        df = pd.read_csv(file_path)
    elif ext in [".xlsx", ".xls"]:
        df = pd.read_excel(file_path)
    else:
        raise ValueError("Phenotype file must be .csv, .xlsx, or .xls")

    if target_col not in df.columns:
        raise ValueError(
            f"Target column '{target_col}' not found in phenotype file. "
            f"Available columns: {list(df.columns)}"
        )

    y = df[target_col].values.astype(np.float32)
    return y


def impute_train_test(X_train, X_test):
    """
    Mean imputation using training-set column means only.
    The same means are then applied to the test set.
    """
    col_mean = np.nanmean(X_train, axis=0)

    # If a column is entirely missing in training, replace its mean with 0
    col_mean = np.where(np.isnan(col_mean), 0, col_mean)

    train_nan = np.where(np.isnan(X_train))
    test_nan = np.where(np.isnan(X_test))

    X_train = X_train.copy()
    X_test = X_test.copy()

    X_train[train_nan] = np.take(col_mean, train_nan[1])
    X_test[test_nan] = np.take(col_mean, test_nan[1])

    return X_train, X_test


def variance_filter_train_test(X_train, X_test, threshold):
    """
    Apply variance filtering using training data only.
    The same selected features are retained in the test data.
    """
    variances = np.var(X_train, axis=0)
    keep = variances > threshold

    if keep.sum() == 0:
        raise ValueError(
            "No features remained after variance filtering. "
            "Try lowering --variance-threshold."
        )

    return X_train[:, keep], X_test[:, keep], keep.sum()


def ccc_score(y_true, y_pred):
    """
    Concordance Correlation Coefficient.
    """
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    mean_true = np.mean(y_true)
    mean_pred = np.mean(y_pred)

    var_true = np.var(y_true)
    var_pred = np.var(y_pred)

    cov = np.mean((y_true - mean_true) * (y_pred - mean_pred))

    numerator = 2 * cov
    denominator = var_true + var_pred + (mean_true - mean_pred) ** 2

    if denominator == 0:
        return np.nan

    return numerator / denominator


def safe_pcc(y_true, y_pred):
    """
    Pearson correlation coefficient.
    Returns NaN if correlation cannot be calculated.
    """
    if np.std(y_true) == 0 or np.std(y_pred) == 0:
        return np.nan

    pcc, _ = pearsonr(y_true, y_pred)
    return pcc


def rmse_score(y_true, y_pred):
    """
    Root mean squared error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))


# ============================================================
# Main function
# ============================================================

def main(args):
    os.makedirs(args.outdir, exist_ok=True)

    print("=" * 70)
    print("Random Forest Multi-Omics Regression")
    print("=" * 70)
    print(f"Target trait: {args.target}")
    print(f"Output directory: {args.outdir}")
    print("=" * 70)

    # --------------------------------------------------------
    # Load omics matrices
    # --------------------------------------------------------
    omics_matrices = []
    omics_names = args.omics_names

    if omics_names is None:
        omics_names = [f"omics_{i+1}" for i in range(len(args.omics))]

    if len(omics_names) != len(args.omics):
        raise ValueError("Number of --omics-names must match number of --omics files.")

    print("\nLoading omics matrices...")
    for name, path in zip(omics_names, args.omics):
        X = load_matrix(path)
        omics_matrices.append(X)
        print(f"  {name}: {X.shape}")

    # --------------------------------------------------------
    # Load phenotype
    # --------------------------------------------------------
    print("\nLoading phenotype...")
    y = load_phenotype(args.phenotypes, args.target)
    print(f"  Phenotype vector: {y.shape}")

    # --------------------------------------------------------
    # Check sample numbers
    # --------------------------------------------------------
    n_samples = len(y)

    for name, X in zip(omics_names, omics_matrices):
        if X.shape[0] != n_samples:
            raise ValueError(
                f"Sample count mismatch for {name}: "
                f"{X.shape[0]} samples in matrix, but {n_samples} phenotypes."
            )

    print(f"\nTotal samples: {n_samples}")

    # --------------------------------------------------------
    # Random Forest parameters
    # --------------------------------------------------------
    rf_params = {
        "n_estimators": args.n_estimators,
        "max_depth": args.max_depth,
        "max_features": args.max_features,
        "min_samples_split": args.min_samples_split,
        "min_samples_leaf": args.min_samples_leaf,
        "random_state": args.random_state,
        "n_jobs": args.n_jobs,
    }

    print("\nRandom Forest parameters:")
    for key, value in rf_params.items():
        print(f"  {key}: {value}")

    # --------------------------------------------------------
    # Cross-validation
    # --------------------------------------------------------
    kfold = KFold(
        n_splits=args.n_splits,
        shuffle=True,
        random_state=args.random_state
    )

    results = []
    all_predictions = []

    print("\nStarting cross-validation...")

    for fold, (train_idx, test_idx) in enumerate(kfold.split(np.arange(n_samples)), start=1):
        print("\n" + "=" * 70)
        print(f"Fold {fold}/{args.n_splits}")
        print("=" * 70)

        y_train = y[train_idx]
        y_test = y[test_idx]

        X_train_parts = []
        X_test_parts = []
        kept_feature_info = {}

        # Preprocess each omics matrix inside the fold
        for name, X in zip(omics_names, omics_matrices):
            X_train = X[train_idx]
            X_test = X[test_idx]

            X_train, X_test = impute_train_test(X_train, X_test)

            X_train, X_test, n_kept = variance_filter_train_test(
                X_train,
                X_test,
                args.variance_threshold
            )

            X_train_parts.append(X_train)
            X_test_parts.append(X_test)

            kept_feature_info[f"{name}_features_kept"] = n_kept
            print(f"  {name}: kept {n_kept:,} features")

        # Feature-level integration of omics layers
        X_train_final = np.hstack(X_train_parts)
        X_test_final = np.hstack(X_test_parts)

        print(f"  Final training matrix: {X_train_final.shape}")
        print(f"  Final testing matrix:  {X_test_final.shape}")

        # Train model
        model = RandomForestRegressor(**rf_params)
        model.fit(X_train_final, y_train)

        # Predict
        y_pred = model.predict(X_test_final)

        # Metrics
        pcc = safe_pcc(y_test, y_pred)
        rmse = rmse_score(y_test, y_pred)
        ccc = ccc_score(y_test, y_pred)

        print(f"  PCC:  {pcc:.4f}")
        print(f"  RMSE: {rmse:.4f}")
        print(f"  CCC:  {ccc:.4f}")

        # Save fold predictions
        pred_df = pd.DataFrame({
            "fold": fold,
            "sample_index": test_idx,
            "true": y_test,
            "predicted": y_pred
        })

        pred_path = os.path.join(args.outdir, f"predictions_fold_{fold}.csv")
        pred_df.to_csv(pred_path, index=False)

        all_predictions.append(pred_df)

        # Save model
        if args.save_models:
            model_path = os.path.join(args.outdir, f"rf_model_fold_{fold}.joblib")
            joblib.dump(model, model_path)

        # Store metrics
        fold_result = {
            "fold": fold,
            "pcc": pcc,
            "rmse": rmse,
            "ccc": ccc,
            **kept_feature_info
        }

        results.append(fold_result)

    # --------------------------------------------------------
    # Save final results
    # --------------------------------------------------------
    results_df = pd.DataFrame(results)

    results_path = os.path.join(args.outdir, "per_fold_metrics.csv")
    results_df.to_csv(results_path, index=False)

    all_pred_df = pd.concat(all_predictions, axis=0)
    all_pred_path = os.path.join(args.outdir, "all_predictions.csv")
    all_pred_df.to_csv(all_pred_path, index=False)

    summary = pd.DataFrame({
        "metric": ["PCC", "RMSE", "CCC"],
        "mean": [
            results_df["pcc"].mean(),
            results_df["rmse"].mean(),
            results_df["ccc"].mean()
        ],
        "std": [
            results_df["pcc"].std(),
            results_df["rmse"].std(),
            results_df["ccc"].std()
        ]
    })

    summary_path = os.path.join(args.outdir, "summary_metrics.csv")
    summary.to_csv(summary_path, index=False)

    print("\n" + "=" * 70)
    print("Final Summary")
    print("=" * 70)
    print(summary.to_string(index=False))

    print("\nSaved files:")
    print(f"  Per-fold metrics: {results_path}")
    print(f"  Summary metrics:  {summary_path}")
    print(f"  All predictions:  {all_pred_path}")
    print("=" * 70)


# ============================================================
# Command-line arguments
# ============================================================

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Random Forest regression for multi-omics phenotype prediction."
    )

    parser.add_argument(
        "--omics",
        nargs="+",
        required=True,
        help="Paths to omics matrices. Example: G_matrix.npy T_matrix.npy M_gbM_matrix.npy"
    )

    parser.add_argument(
        "--omics-names",
        nargs="+",
        default=None,
        help="Names of omics layers. Example: G T gbM"
    )

    parser.add_argument(
        "--phenotypes",
        required=True,
        help="Path to phenotype file, .csv or .xlsx."
    )

    parser.add_argument(
        "--target",
        required=True,
        help="Target phenotype column name."
    )

    parser.add_argument(
        "--outdir",
        required=True,
        help="Directory to save results."
    )

    parser.add_argument(
        "--variance-threshold",
        type=float,
        default=0.01,
        help="Variance threshold for feature filtering. Default: 0.01"
    )

    parser.add_argument(
        "--n-splits",
        type=int,
        default=10,
        help="Number of cross-validation folds. Default: 10"
    )

    parser.add_argument(
        "--n-estimators",
        type=int,
        default=100,
        help="Number of trees in the Random Forest. Default: 100"
    )

    parser.add_argument(
        "--max-depth",
        type=int,
        default=10,
        help="Maximum depth of each tree. Default: 10"
    )

    parser.add_argument(
        "--max-features",
        default="sqrt",
        help="Number of features considered at each split. Default: sqrt"
    )

    parser.add_argument(
        "--min-samples-split",
        type=int,
        default=5,
        help="Minimum samples required to split an internal node. Default: 5"
    )

    parser.add_argument(
        "--min-samples-leaf",
        type=int,
        default=2,
        help="Minimum samples required at each leaf node. Default: 2"
    )

    parser.add_argument(
        "--random-state",
        type=int,
        default=42,
        help="Random seed. Default: 42"
    )

    parser.add_argument(
        "--n-jobs",
        type=int,
        default=-1,
        help="Number of CPU cores to use. Default: -1 uses all cores"
    )

    parser.add_argument(
        "--save-models",
        action="store_true",
        help="Save trained model for each fold."
    )

    args = parser.parse_args()
    main(args)